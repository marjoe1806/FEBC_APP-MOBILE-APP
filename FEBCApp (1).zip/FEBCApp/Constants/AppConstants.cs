﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Constants
{
    public static class AppConstants
    {
        public const string SyncfusionLicenseKey = "MjQ4MzE5QDMxMzgyZTMxMmUzMEsyTUVPVXB2Q1hhQk1HZTN3Qm5DNGhWTG5ONW1ZRmtqdmdUdkc1UDV3ajQ9";
    }
}
