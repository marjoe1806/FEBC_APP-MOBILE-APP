﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Models;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using FFImageLoading;
using Newtonsoft.Json;
using Plugin.Media.Abstractions;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Text.RegularExpressions;

namespace FEBCApp.ViewModels
{
    public class SignupPageViewModel : BaseNavigationViewModel
    {
        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;
        private readonly IMedia _media;
        private byte[] _takePhotoSource;
        private bool _hasImage;

        public SignupPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings, IMedia media) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;
            _media = media;

            SignupCommand = new DelegateCommand(Signup);
            TermsCommand = new DelegateCommand(Terms);
            BackCommand = new DelegateCommand(Back);
            PolicyCommand = new DelegateCommand(Policy);
            PickPhotoCommand = new DelegateCommand(PickPhoto);
        }

     

        public override void OnNavigatedTo(INavigationParameters parameters)
        {
            _hasImage = false;
            PictureSource = ImageSource.FromFile("user.png");
        }

        #region Bindable Commands
        public ICommand SignupCommand { get; private set; }
        public ICommand BackCommand { get; private set; }
        public ICommand TermsCommand { get; private set; }
        public ICommand PolicyCommand { get; private set; }
        public ICommand PickPhotoCommand { get; private set; }
        #endregion

        #region Bindable Properties
        private string _email;
        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }

        private string _username;
        public string Username
        {
            get => _username;
            set => SetProperty(ref _username, value);
        }

        private string _password;
        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set => SetProperty(ref _lastName, value);
        }

        private string _selectedGender;
        public string SelectedGender
        {
            get => _selectedGender;
            set => SetProperty(ref _selectedGender, value);
        }

        private string _selectedAgeRange;
        public string SelectedAgeRange
        {
            get => _selectedAgeRange;
            set => SetProperty(ref _selectedAgeRange, value);
        }

        private string _selectedCountry;
        public string SelectedCountry
        {
            get => _selectedCountry;
            set => SetProperty(ref _selectedCountry, value);
        }

        private string _city;
        public string City
        {
            get => _city;
            set => SetProperty(ref _city, value);
        }

        private string _province;
        public string Province
        {
            get => _province;
            set => SetProperty(ref _province, value);
        }

        private ImageSource _pictureSource;
        public ImageSource PictureSource
        {
            get => _pictureSource;
            set => SetProperty(ref _pictureSource, value);
        }
        #endregion

        #region Methods
        private async void Signup()
        {


            if (string.IsNullOrEmpty(FirstName))
            {
                _userDialogs.Alert("First Name is required!");
                return;
            }

            if (string.IsNullOrEmpty(LastName))
            {
                _userDialogs.Alert("Last Name is required!");
                return;
            }

            if (string.IsNullOrEmpty(Email))
            {
                _userDialogs.Alert("Email address is required!");
                return;
            }
           

            if (!IsValidEmail(Email))
            {
                _userDialogs.Alert("Please enter a valid email");
                return;
            }
            if (string.IsNullOrEmpty(Username))
            {
                _userDialogs.Alert("Username is required!");
                return;
            }

            if (string.IsNullOrEmpty(Password))
            {
                _userDialogs.Alert("Password is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedGender))
            {
                _userDialogs.Alert("Gender is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedAgeRange))
            {
                 _userDialogs.Alert("Age is required!");
                 return;
             }

            if (string.IsNullOrEmpty(SelectedCountry))
            {
                _userDialogs.Alert("Country is required!");
                 return;
            }

            if (string.IsNullOrEmpty(City))
            {
                _userDialogs.Alert("City is required!");
                return;
            }

            if (string.IsNullOrEmpty(Province))
            {
                _userDialogs.Alert("Province is required!");
                return;
            }

            var loading = _userDialogs.Loading("Please wait...");

            try
            {

                RegisterDto registerDto = new RegisterDto
                {
                    Email = Email,
                    Username = Username,
                    Password = Password,
                    Firstname = FirstName,
                    Lastname = LastName,
                    Gender = SelectedGender,
                    Age = SelectedAgeRange,
                    Country = SelectedCountry,
                    City = City,
                    Province = Province,
                    Usertype = "public"
                };

               

                string result = await RegisterUser(registerDto);
                UserData response = ParseResponse(result);
                var response2 = await getApiData(Email);
                //_userDialogs.Alert(result);


                if (response.Message.Contains("already"))
                {
                    loading.Hide();
                    _userDialogs.Alert("Email Already Exist");
                    return;
                }

                var client = new SendGridClient(App.SendGridApiKey);
                var from = new EmailAddress("marjoe.aguilar18@gmail.com", "FEBC PH Stream");
                var subject = "Your FEBC PH Stream Account is Ready - Start Listening Now";
                var to = new EmailAddress(Email, FirstName);
                var plainTextContent = "Successfully Register!";
                var htmlContent =
                    $"<strong> " +
                    $" Dear {FirstName} {LastName},"+
                    $" <br><br><br> " +
                    $"Thank you for completing your FEBC App registration. " +
                    $"<br><br><br> " +
                    $"This email confirms that your account has been activated and that you are now an officially part of the FEBC family." +
                    $" <br> " +
                    $"Enjoy!" +
                    $"<br><br><br>" +
                    $" Regards," +
                    $"<br>" +
                    $"Team FEBC" +
                    $"</strong>";
                var message = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
                var response1 = await client.SendEmailAsync(message);

                _appSettings.IsAuthenticated = true;
                _appSettings.FirstName = response2.Firstname;
                _appSettings.LastName = response2.Lastname;
                _appSettings.AgeRange = response2.Age;
                _appSettings.City = response2.City;
                _appSettings.Country = response2.Country;
                _appSettings.Gender = response2.Gender;
                _appSettings.Id = response2.Id;
                //_appSettings.Usertype = "public";

                if (_takePhotoSource != null)
                {

                    RegistrationResponse imageUploaded = await UploadImage(_takePhotoSource, response2.Id);
                   //_appSettings.Avatar = $"{imageUploaded.Avatar}";
                }

                loading.Hide();
                _userDialogs.Alert("You have successfully created your account.", "Success!");
                //await NavigationService.NavigateAsync(nameof(HomePage));
                await NavigationService.NavigateAsync(nameof(LoginPage));
            }
            catch (Exception)
            {
                loading.Hide();
                //_userDialogs.Alert("Could not process request");
                _userDialogs.Alert("Email Already Exist!");
                //await NavigationService.NavigateAsync(nameof(LoginPage));
            }
        }

        private bool IsValidEmail(string email)
        {
            // Define a regular expression pattern for a valid email address
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            // Use the Regex class to check if the email matches the pattern
            Regex regex = new Regex(pattern);
            return regex.IsMatch(email);
        }

        public async Task<UserData> getApiData(string email)
        {
            var httpClient = new HttpClient();
            var json = await httpClient.GetStringAsync($"{ApiConstants.BaseUrl}user/get-email/" + email);
            UserData userdetails = JsonConvert.DeserializeObject<UserData>(json);

            return userdetails;

        }

        private async void Terms()
        {
            await Launcher.OpenAsync(new Uri("https://febc.ph/terms-and-conditions-of-use/"));
        }

        private async void Policy()
        {
            await Launcher.OpenAsync(new Uri("https://febc.ph/terms-and-conditions-of-use/"));
        }

        private void Back()
        {
            NavigationService.GoBackAsync();
        }

        //SendGrid Api Key
        //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

        private async void PickPhoto()
        {

            string[] options = new string[] { "Take a photo with camera", "Choose a photo from gallery"};

            var action = await _userDialogs.ActionSheetAsync("Add Photo!", "", "Cancel", null, options);


            if (action == "Take a photo with camera")
            {
                // Take a photo using TakePhotoAsync
                if (_media.IsCameraAvailable && _media.IsTakePhotoSupported)
                {
                    try
                    {
                        var takePhoto = await _media.TakePhotoAsync(
                            new StoreCameraMediaOptions
                            {
                                Directory = "FEBC",
                                Name = $"{_appSettings.Id}_PROFILE_PIC.jpg",
                                PhotoSize = PhotoSize.Full,
                                SaveToAlbum = true,
                                DefaultCamera = CameraDevice.Front,
                                CompressionQuality = 92
                            });

                        using (MemoryStream stream = new MemoryStream())
                        {
                            takePhoto.GetStream().CopyTo(stream);

                            _takePhotoSource = stream.ToByteArray();
                        }

                        PictureSource = ImageSource.FromStream(() =>
                        {
                            takePhoto.Dispose();
                            return new MemoryStream(_takePhotoSource);
                        });
                    }
                    catch (Exception)
                    {
                        //_userDialogs.Alert(ex.Message);
                        PictureSource = ImageSource.FromFile("user.png");
                    }
                }
            }
            else if (action == "Choose a photo from gallery")
            {
                try
                {
                    if (_media.IsPickPhotoSupported)
                    {
                        var pickPhoto = await _media.PickPhotoAsync();
                        using (MemoryStream stream = new MemoryStream())
                        {
                            pickPhoto.GetStream().CopyTo(stream);

                            _takePhotoSource = stream.ToByteArray();
                        }

                        PictureSource = ImageSource.FromStream(() =>
                        {
                            pickPhoto.Dispose();
                            return new MemoryStream(_takePhotoSource);
                        });
                    }
                }
                catch (Exception)
                {
                    //_userDialogs.Alert(ex.Message);
                    PictureSource = ImageSource.FromFile("user.png");
                }
                // Pick a photo using PickPhotoAsync

            }

        }

        private async Task<string> RegisterUser(RegisterDto registerDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(registerDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}user/register", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;
        }

        private UserData ParseResponse(string response)
        {
            return JsonConvert.DeserializeObject<UserData>(response);
        }

        private async Task<RegistrationResponse> UploadImage(byte[] stream, string id)
        {
            HttpClient client = new HttpClient();
            ByteArrayContent content = new ByteArrayContent(stream);
            MultipartFormDataContent formData = new MultipartFormDataContent();
            content.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
            {
                FileName = $"{_appSettings.Id}_PROFILE_PIC.jpg",
                Name = "avatar"
            };
            content.Headers.ContentType = new MediaTypeHeaderValue("image/jpg");

            formData.Add(content);

            try
            {

                var result = await client.PostAsync($"{ApiConstants.BaseUrl}user/update-avatar/{id}", formData);
                string response = await result.Content.ReadAsStringAsync();
                //_userDialogs.Alert(response);
                //_userDialogs.Alert(id);

                return JsonConvert.DeserializeObject<RegistrationResponse>(response);
            }
            catch (Exception)
            {
                return new RegistrationResponse();
            }
        }
        #endregion
    }
}
