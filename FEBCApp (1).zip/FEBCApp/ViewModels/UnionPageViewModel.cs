﻿using System;
using System.Windows.Input;
using Acr.UserDialogs;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using Prism.Commands;
using Prism.Navigation;
using Xamarin.Forms;
using FEBCApp.Services.Base;
using FEBCApp.Helpers;
using ImTools;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using FEBCApp.Settings.Base;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net.Http;
using FEBCApp.Constants;
using FEBCApp.Models;
using Xamarin.Essentials;
using System.Text;
using FEBCApp.Services.Cybersource;
using System.Text.RegularExpressions;
using System.Linq;

namespace FEBCApp.ViewModels
{
    public class UnionPageViewModel : BaseNavigationViewModel
    {

        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;
        private const string merchantId = "006010000017694";
        private const string profileId = "5ACE8595-AB61-438C-9574-44A0C33C68AF";
        private const string accessKey = "e6f3bb1de8c0341bad37d79f84e6cd3d";
        private const string secretKey = "1b92507b6eb3423e8e0339095657558c45f7c14ad7fb4387b59615ffbd2b6ad47cb6a565bb1b4f769c1a5290b06ba563ab7ff408335d4c30885c4bde242e04ce9558165222d5485cbbdc60d8130c6e21b97f80e2509f4d22b7e1b9735fc4e18555022ce883084f0d846a155a3e3511041f8da6bedeea482a9294b48333e85364";
        private DonationService donationService;
        [Obsolete]
        public UnionPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, Settings.Base.IAppSettings appSettings) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;


            BackCommand = new DelegateCommand(Back);
            DonateCommand = new DelegateCommand(Donation);
            TermsCommand = new DelegateCommand(Terms);


        }

        #region Bindable Commands
        public ICommand BackCommand { get; private set; }
        public ICommand DonateCommand { get; private set; }
        public ICommand TermsCommand { get; private set; }
        #endregion

        private string _cardTypePicker;
        public string CardTypePicker
        {
            get => _cardTypePicker;
            set
            {
                SetProperty(ref _cardTypePicker, value);
                UpdateCCV();
            }


        }

        private string _amountEntry;
        public string AmountEntry
        {
            get => _amountEntry;
            set => SetProperty(ref _amountEntry, value);
        }

        private string _cardNumberEntry;
        public string CardNumberEntry
        {
            get => _cardNumberEntry;
            set => SetProperty(ref _cardNumberEntry, value);
        }

        private string _expiryMonthPicker;
        public string ExpiryMonthPicker
        {
            get => _expiryMonthPicker;
            set => SetProperty(ref _expiryMonthPicker, value);
        }

        private string _expiryYearPicker;
        public string ExpiryYearPicker
        {
            get => _expiryYearPicker;
            set => SetProperty(ref _expiryYearPicker, value);
        }

        private string _cVVEntry;
        public string CVVEntry
        {
            get => _cVVEntry;
            set => SetProperty(ref _cVVEntry, value);
        }

        private string _l;
        public string L
        {
            get => _l;
            set => SetProperty(ref _l, value);
        }


        private void UpdateCCV()
        {
            if (CardTypePicker == "Visa")
            {
                L = "3";
            }
            else if (CardTypePicker == "Mastercard")
            {
                L = "3";
            }
            else if (CardTypePicker == "American Express")
            {
                L = "4";
            }
            else
            {
                L = string.Empty;
            }
        }



        #region Methods
        public void Back()
        {
            //NavigationService.NavigateAsync(nameof(HandshakePage));
            //NavigationService.NavigateAsync(nameof(DonationPage));
            NavigationService.GoBackAsync();
        }

        private void Terms()
        {
            _userDialogs.Alert($"This SERVICE is provided by the FEBC Stream at no cost and is intended for use as is. " +
                $"This page is used to inform visitors regarding our policies with the collection, use and disclosure of Personal Information should you decide to use our Service." +
                $"If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is simply used for providing and improving the Service. We will not use or share your information with anyone except as described in this Privacy Policy." +
                $"The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at the FEBC Stream unless otherwise defined in this Privacy Policy." +
                $"Information Collection and Use" +
                $"For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information. The information that we request will be retained by us and used as described in this Privacy Policy." +
                $"We may collect information about the devices you use to access our platform, including hardware models, operating systems, OS versions and unique device identifiers." +
                $"When you interact with our platform, we collect server logs, which may include information like device IP address, access dates and times, app features or pages viewed, app crashes and other system activity." +
                $"The FEBC Stream uses the information it collects to personalize, maintain and improve its products and services, to help maintain the safety and integrity of its platform by preventing fake and fraud accounts, to assist you when you contact its customer support team and to investigate or address claims or disputes to your use of the FEBC Stream platform or as otherwise allowed by applicable law." +
                $"Cookies" +
                $"Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device’s internal memory." +
                $"The app may use third party code and libraries that use “cookies” to collect information and improve their Services, such as authenticating users and remembering user preferences and settings. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service." +
                $"Service Providers" +
                $"The FEBC Stream may share your information if it is required by applicable law, regulation, operating agreement, legal process or governmental request and if we notify you and you consent to the sharing." +
                $"Information Retention and Deletion" +
                $"The FEBC Stream retains your information while your account remains active, unless you ask us to delete your information or your account." +
                $"Subject to the exceptions described below, the FEBC Stream deletes your information upon request. Subject to applicable law, the FEBC Stream may retain information after account deletion:" +
                $"1. If there is an unresolved issue relating to your account, such as unresolved claim or dispute;" +
                $"2. If the FEBC Stream is required to by applicable law;" +
                $"3. The FEBC Stream may also retain certain information if necessary for its legitimate business interests, such as fraud prevention and enhancing user safety and security." +
                $"Changes to This Privacy Policy" +
                $"We may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately after they are posted on this page.",

                "PRIVACY POLICY");
        }




        [Obsolete]
        private async void Donation()
        {
            if (string.IsNullOrEmpty(AmountEntry))
            {
                _userDialogs.Alert("Donation amount is required!");
                return;
            }

            if (string.IsNullOrEmpty(CardNumberEntry))
            {
                _userDialogs.Alert("Card Number is required!");
                return;
            }

            // Validate card number using regular expression
            Regex cardNumberRegex = new Regex(@"^\d{16}$");
            if (!cardNumberRegex.IsMatch(CardNumberEntry))
            {
                _userDialogs.Alert("Invalid Card Number must be 16 digits!");
                return;
            }

            if (string.IsNullOrEmpty(ExpiryYearPicker))
            {
                _userDialogs.Alert("Expiry Year is required!");
                return;
            }

            if (string.IsNullOrEmpty(ExpiryMonthPicker))
            {
                _userDialogs.Alert("Expiry Month is required!");
                return;
            }


            if (string.IsNullOrEmpty(CVVEntry))
            {
                _userDialogs.Alert("CVV is required!");
                return;
            }


            if (CardTypePicker == "Visa" && (CVVEntry.Length != 3 || !Regex.IsMatch(CVVEntry, @"^\d+$")))
            {
                L = "3";
                _userDialogs.Alert("Invalid CVV for Visa card type. CVV must be 3 digits.");
                return;
            }
            else if (CardTypePicker == "Mastercard" && (CVVEntry.Length != 3 || !Regex.IsMatch(CVVEntry, @"^\d+$")))
            {
                L = "3";
                _userDialogs.Alert("Invalid CVV for Mastercard card type. CVV must be 3 digits.");
                return;
            }
            else if (CardTypePicker == "American Express" && (CVVEntry.Length != 4 || !Regex.IsMatch(CVVEntry, @"^\d+$")))
            {
                L = "4";
                _userDialogs.Alert("Invalid CVV for American Express card type. CVV must be 4 digits.");
                return;
            }

            var loading = _userDialogs.Loading("Please wait...");

            try
            {
                // Step 1: Authentication

                // Set up the API endpoint URL for authentication
                string authUrl = "https://api-uat.unionbankph.com/partners/sb/convergent/v1/oauth2/authorize";

                // Create an HTTP client for authentication
                 HttpClient authClient = new HttpClient();

                // Set the required headers for authentication
                authClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                authClient.DefaultRequestHeaders.Add("x-ibm-client-id", accessKey);
                authClient.DefaultRequestHeaders.Add("x-ibm-client-secret", secretKey);
                authClient.DefaultRequestHeaders.Add("x-partner-id", profileId);

                // Create an HTTP request message for authentication
                 HttpRequestMessage authRequest = new HttpRequestMessage(HttpMethod.Post, authUrl);

                // Send the authentication request
                HttpResponseMessage authResponse = await authClient.SendAsync(authRequest);

                // Handle the authentication response
                if (authResponse.IsSuccessStatusCode)
                {
                    // Authentication succeeded
                    // Read the response content as a string
                    string authResponseContent = await authResponse.Content.ReadAsStringAsync();

                    // Parse the authentication response JSON
                    dynamic authResponseJson = JsonConvert.DeserializeObject(authResponseContent);

                    // Retrieve the access token from the authentication response
                    string accessToken = authResponseJson.access_token;

                    // Step 2: Donation Payment

                    // Set up the API endpoint URL for donation payment
                    string donationUrl = "https://api-uat.unionbankph.com/partners/sb/online/v1/transfers/single";

                    // Prepare the request payload for donation payment
                    var requestBody = new
                    {
                        senderRefId = "00001",
                        tranRequestDate = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fff"),
                        accountNo = CardNumberEntry,
                        amount = new
                        {
                            currency = "PHP",
                            value = AmountEntry
                        },
                        remarks = "Donation",
                        particulars = "Donation"
                    };

                    // Convert the request payload to JSON
                    string jsonPayload = JsonConvert.SerializeObject(requestBody);

                    // Create an HTTP client for donation payment
                     HttpClient donationClient = new HttpClient();

                    // Set the required headers for donation payment
                    donationClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    donationClient.DefaultRequestHeaders.Add("x-ibm-client-id", accessKey);
                    donationClient.DefaultRequestHeaders.Add("x-ibm-client-secret", secretKey);
                    donationClient.DefaultRequestHeaders.Add("x-partner-id", profileId);
                    donationClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    // Create an HTTP request message for donation payment
                     HttpRequestMessage donationRequest = new HttpRequestMessage(HttpMethod.Post, donationUrl);
                    donationRequest.Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                    // Send the donation payment request
                    HttpResponseMessage donationResponse = await donationClient.SendAsync(donationRequest);

                    // Handle the donation payment response
                    if (donationResponse.IsSuccessStatusCode)
                    {
                        // Donation payment initiated successfully
                        // You may need to parse the response JSON for further processing
                        string donationResponseContent = await donationResponse.Content.ReadAsStringAsync();

                        // Parse the donation payment response JSON
                        dynamic donationResponseJson = JsonConvert.DeserializeObject(donationResponseContent);

                        // Access the donation payment details
                        string donationId = donationResponseJson.donationId;
                        string redirectUrl = donationResponseJson.redirectUrl;
                        // Other donation payment properties

                        // Perform further processing based on the donation payment details
                        // For example, you can open the redirect URL in a WebView to proceed with the donation payment flow
                        OpenDonationWebView(redirectUrl);
                    }
                    else
                    {
                        // Donation payment initiation failed with a non-success status code
                        // Read the response content as a string
                        string errorContent = await donationResponse.Content.ReadAsStringAsync();

                        // Handle the failure based on the error content
                        // Handle the failure based on the error content
                        if (!string.IsNullOrEmpty(errorContent))
                        {
                            dynamic errorResponse = JsonConvert.DeserializeObject(errorContent);

                            // Access the error properties
                            string errorMessage = errorResponse.errorMessage;
                            int? errorCode = errorResponse.errorCode; // Nullable int

                            // Handle the specific error based on the error properties
                            // For example, display an error message to the user or log the error
                            if (errorCode.HasValue)
                            {
                                DisplayErrorMessage($"Error {errorCode}: {errorMessage}");
                            }
                            else
                            {
                                DisplayErrorMessage(errorMessage);
                            }
                            loading.Hide();
                        }
                        else
                        {
                            // Handle the failure without an error message
                            // This might occur if there is a network issue or unexpected response format
                            loading.Hide();
                            DisplayErrorMessage("Failed to initiate the donation. Please check your network connection and try again.");
                        }
                    }
                }
                else
                {
                    // Authentication failed with a non-success status code
                    // Read the response content as a string
                    string errorContent = await authResponse.Content.ReadAsStringAsync();

                    // Handle the failure based on the error content
                  // Handle the failure based on the error content
        if (!string.IsNullOrEmpty(errorContent))
        {
            // Parse the error response JSON
            dynamic errorResponse = JsonConvert.DeserializeObject(errorContent);

            // Access the error properties
            string errorMessage = errorResponse.errorMessage;
            int? errorCode = errorResponse.errorCode; // Nullable int
            // Other error properties

            // Handle the specific error based on the error properties
            // For example, display an error message to the user or log the error
            if (errorCode.HasValue)
            {
                DisplayErrorMessage($"Error {errorCode}: {errorMessage}");
            }
            else
            {
                DisplayErrorMessage(errorMessage);
            }
            loading.Hide();
        }
                    else
                    {
                        // Handle the failure without an error message
                        // This might occur if there is a network issue or unexpected response format
                        loading.Hide();
                        DisplayErrorMessage("Failed to authenticate. Please check your network connection and try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                loading.Hide();
                DisplayErrorMessage("An error occurred: " + ex.Message);
            }
            finally
            {
                loading.Hide();
            }
        }


        // Method to display an error message to the user
        private void DisplayErrorMessage(string errorMessage)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                await _userDialogs.AlertAsync(errorMessage, "Error", "OK");
                _userDialogs.HideLoading();
            });
        }

        // Method to open the donation WebView
        [Obsolete]
        private void OpenDonationWebView(string redirectUrl)
        {
            Device.OpenUri(new Uri(redirectUrl));
        }
        #endregion
    }
}



