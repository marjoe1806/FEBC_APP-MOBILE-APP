﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;

public class UnionBankApiClient
{
    private readonly HttpClient httpClient;
    private const string ApiBaseUrl = "https://api.unionbank.com";

    private readonly string merchantId = "006010000017694";
    private readonly string profileId = "5ACE8595-AB61-438C-9574-44A0C33C68AF";
    private readonly string accessKey = "e6f3bb1de8c0341bad37d79f84e6cd3d";
    private readonly string secretKey = "1b92507b6eb3423e8e0339095657558c45f7c14ad7fb4387b59615ffbd2b6ad47cb6a565bb1b4f769c1a5290b06ba563ab7ff408335d4c30885c4bde242e04ce9558165222d5485cbbdc60d8130c6e21b97f80e2509f4d22b7e1b9735fc4e18555022ce883084f0d846a155a3e3511041f8da6bedeea482a9294b48333e85364";

    public UnionBankApiClient()
    {
        httpClient = new HttpClient();
    }

    private string GenerateSignature(string url, string httpMethod, string requestBody, string timestamp)
    {
        string payload = $"{url}{httpMethod}{requestBody}{timestamp}";
        byte[] secretKeyBytes = Encoding.UTF8.GetBytes(secretKey);
        byte[] payloadBytes = Encoding.UTF8.GetBytes(payload);

        using (var hmacSha256 = new HMACSHA256(secretKeyBytes))
        {
            byte[] hashBytes = hmacSha256.ComputeHash(payloadBytes);
            string signature = Convert.ToBase64String(hashBytes);
            return signature;
        }
    }

    private void AuthenticateRequest(HttpRequestMessage request, string requestBody)
    {
        string timestamp = DateTimeOffset.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
        string url = HttpUtility.UrlEncode(request.RequestUri.ToString());
        string httpMethod = request.Method.Method.ToUpperInvariant();
        string signature = GenerateSignature(url, httpMethod, requestBody, timestamp);

        request.Headers.Add("x-ibm-client-id", accessKey);
        request.Headers.Add("x-ibm-client-secret", secretKey);
        request.Headers.Add("x-merchant-id", merchantId);
        request.Headers.Add("x-profile-id", profileId);
        request.Headers.Add("x-timestamp", timestamp);
        request.Headers.Add("x-signature", signature);
    }

    public async Task<string> MakeApiRequest(string endpoint, HttpMethod httpMethod, object requestBody = null)
    {
        string requestJson = requestBody != null ? JsonConvert.SerializeObject(requestBody) : null;
        var request = new HttpRequestMessage(httpMethod, $"{ApiBaseUrl}/{endpoint}");
        AuthenticateRequest(request, requestJson);

        if (requestJson != null)
        {
            request.Content = new StringContent(requestJson, Encoding.UTF8, "application/json");
        }

        HttpResponseMessage response = await httpClient.SendAsync(request);

        if (response.IsSuccessStatusCode)
        {
            string responseJson = await response.Content.ReadAsStringAsync();
            return responseJson;
        }
        else
        {
            throw new Exception($"API request failed with status code {response.StatusCode}");
        }
    }
}

