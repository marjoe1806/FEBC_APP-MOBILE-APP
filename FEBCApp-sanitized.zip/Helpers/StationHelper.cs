﻿using FEBCApp.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Helpers
{
    public static class StationHelper
    {
        public static List<Station> GetRadioStation()
        {
            return new List<Station>()
            {
                new Station()
                {
                    Count = "0",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dzas",
                    ImageUrl = "DZAS_702.png",
                    FacebookLink = "https://www.facebook.com/702DZAS/",
                    MessengerLink = "https://m.me/702DZAS"
                },
                new Station()
                {
                    Count = "1",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dzfe",
                    ImageUrl = "DZFE_987.png",
                    FacebookLink = "https://www.facebook.com/98.7DZFE/",
                    MessengerLink = "https://m.me/98.7DZFE"
                },
                new Station()
                {
                    Count = "2",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/nowxd",
                    ImageUrl = "NOW_XD.png",
                    FacebookLink = "https://www.facebook.com/NowXDFEBC/",
                    MessengerLink = "https://m.me/NowXDFEBC"
                },
                new Station()
                {
                    Count = "3",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_pcon",
                    ImageUrl = "PCON.png",
                    FacebookLink = "https://www.facebook.com/pinoyconnection/",
                    MessengerLink = "https://m.me/pinoyconnection"
                },
                new Station()
                {
                    Count = "4",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dway",
                    ImageUrl = "CARE_104_DWAY.png",
                    FacebookLink = "https://www.facebook.com/care104.3thewayfm/",
                    MessengerLink = "https://m.me/care104.3thewayfm"
                },
                new Station()
                {
                    Count = "5",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dxki",
                    ImageUrl = "DXKI_1062.png",
                    FacebookLink = "https://www.facebook.com/1062DXKIFEBCRadio/",
                    MessengerLink = "https://m.me/1062DXKIFEBCRadio"
                },
                new Station()
                {
                    Count = "6",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dyfr",
                    ImageUrl = "UP_987_DYFR.png",
                    FacebookLink = "https://www.facebook.com/UP987DYFRFM/",
                    MessengerLink = "https://m.me/UP987DYFRFM"
                },
                new Station()
                {
                    Count = "7",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dxfe",
                    ImageUrl = "DXFE_1197.png",
                    FacebookLink = "https://www.facebook.com/1197DXFE/",
                    MessengerLink = "https://m.me/1197DXFE"
                },
                new Station()
                {
                    Count = "8",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dyvs",
                    ImageUrl = "DYVS_1233.png",
                    FacebookLink = "https://www.facebook.com/1233Dyvs/",
                    MessengerLink = "https://m.me/1233Dyvs"
                },
                 new Station()
                {
                    Count = "9",
                    StationUrl = "http://ph-icecast-win.eradioportal.com:8000/dxjl",
                    ImageUrl = "DXJL_FM.png",
                    FacebookLink = "https://www.facebook.com/thenewj",
                    MessengerLink = "https://m.me/thenewj"
                },
                  new Station()
                {
                    Count = "10",
                    StationUrl = "http://sg-icecast.eradioportal.com:8000/febc_dzmr",
                    ImageUrl = "DZMR_AM_545x1001.png",
                    FacebookLink = "https://www.facebook.com/DZMR1143",
                    MessengerLink = "https://m.me/1143DZMR"
                }, 
               
            };
        }
    }
}
