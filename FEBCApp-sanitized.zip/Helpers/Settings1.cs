﻿using System;
using System.Collections.Generic;
using System.Text;
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace FEBCApp.Helpers
{
    class Settings1
    {
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        #region Setting Constants

        private const string LastEmailSettingsKey = "last_email_key";
        private const string LastIdSettingsKey = "last_id_key";
        private const string UserEmailSettingsKey = "last_user_key";

        private static readonly string SettingsDefault = string.Empty;

        #endregion


        public static string DonationCategory
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastEmailSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastEmailSettingsKey, value);
            }
        }
        public static string DonationAmount
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastIdSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastIdSettingsKey, value);
            }
        }

        public static string UserEmail
        {
            get
            {
                return AppSettings.GetValueOrDefault(UserEmailSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(UserEmailSettingsKey, value);
            }
        }
    }
}
