﻿using System;
using System.Collections.Generic;
using System.Text;
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace FEBCApp.Helpers
{
    class DonationInfo
    {
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        #region Setting Constants

        private const string LastEmailSettingsKey = "last_email_key";
        private const string FirstnameSettingsKey = "firstname_key";
        private const string LastnameSettingsKey = "lastname_key";
        private const string CountrySettingsKey = "country_key";
        private const string CitySettingsKey = "city_key";
        private const string StatedSettingsKey = "stated_key";
        private const string ZipcodelSettingsKey = "zipcode_key";
        private const string AddressSettingsKey = "address_key";
      



        private static readonly string SettingsDefault = string.Empty;

        #endregion


        public static string Email
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastEmailSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastEmailSettingsKey, value);
            }
        }
        public static string Firstname
        {
            get
            {
                return AppSettings.GetValueOrDefault(FirstnameSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(FirstnameSettingsKey, value);
            }
        }

        public static string Lastname
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastnameSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastnameSettingsKey, value);
            }
        }

        public static string Country
        {
            get
            {
                return AppSettings.GetValueOrDefault(CountrySettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(CountrySettingsKey, value);
            }

        }

        public static string City
        {
            get
            {
                return AppSettings.GetValueOrDefault(CitySettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(CitySettingsKey, value);
            }
        }

        public static string State
        {
            get
            {
                return AppSettings.GetValueOrDefault(StatedSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(StatedSettingsKey, value);
            }
        }


        public static string Zipcode
        {
            get
            {
                return AppSettings.GetValueOrDefault(ZipcodelSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(ZipcodelSettingsKey, value);
            }
        }

        public static string Address1
        {
            get
            {
                return AppSettings.GetValueOrDefault(AddressSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(AddressSettingsKey, value);
            }
        }
    }
}
