﻿using System;
using System.Collections.Generic;
using System.Text;
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace FEBCApp.Helpers
{
    class Settings2
    {
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        #region Setting Constants

        private const string LastEmailSettingsKey = "last_email_key";
        private const string LastIdSettingsKey = "last_id_key";
        private static readonly string SettingsDefault = string.Empty;

        #endregion


        public static string ForgotPassEmail
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastEmailSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastEmailSettingsKey, value);
            }
        }
        public static string UserId
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastIdSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastIdSettingsKey, value);
            }
        }
    }
}
