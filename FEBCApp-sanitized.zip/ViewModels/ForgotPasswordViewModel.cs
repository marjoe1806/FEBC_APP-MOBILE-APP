﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Models;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using FFImageLoading;
using Newtonsoft.Json;
using Plugin.Media.Abstractions;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace FEBCApp.ViewModels
{
    public class ForgotPasswordPageViewModel : BaseNavigationViewModel
    {
        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;
        //private readonly IMedia _media;
        //private byte[] _takePhotoSource;
        //private bool _hasImage;

        public ForgotPasswordPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;
            //_media = media;

            SendLinkCommand = new DelegateCommand(Send);
            TermsCommand = new DelegateCommand(Terms);
            BackCommand = new DelegateCommand(Back);

        }



        #region Bindable Commands
        public ICommand SendLinkCommand { get; private set; }
        public ICommand BackCommand { get; private set; }
        public ICommand TermsCommand { get; private set; }
        public ICommand PolicyCommand { get; private set; }
        public ICommand PickPhotoCommand { get; private set; }
        #endregion

        #region Bindable Properties

        private string _pass;
        public string Pass
        {
            get => _pass;
            set => SetProperty(ref _pass, value);
        }

        private string _email;
        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }



        #endregion

        #region Methods
        private async void Send()
        {

            if (string.IsNullOrEmpty(Email))
            {
                _userDialogs.Alert("Email Address is required!");
                return;
            }



            var loading = _userDialogs.Loading("Please wait...");

            try
            {
                LoginDto loginDto = new LoginDto
                {
                    Username = Email
                };


                string result = await RegisterUser(loginDto);
                UserData response = ParseResponse(result);

                //if (Email == "aguilar.marjoe@mobilemoney.ph")
                {
                    //Auto generated password
                    const string validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-+={}[]\\|<>,.?/~`";
                    var random = new Random();
                    var buffer = new char[6];

                    for (int i = 0; i < 6; i++)
                    {
                        buffer[i] = validChars[random.Next(validChars.Length)];
                    }

                    string Pass = new string(buffer);

                    //await DisplayAlert("Pass", pass, "Ok");
                    // Send an email to the user containing the temporary password and a link to the reset password page
                    SendPasswordResetEmail(Email, Pass);

                   // _userDialogs.Alert("Success", "An email with instructions on how to reset your password has been sent to your email address", "OK");
                    //await Navigation.PopAsync();
                }

                var parameters = new NavigationParameters
                {
                    { "Email", Email },
                    { "Pass", Pass }
                };

                loading.Hide();
                await NavigationService.NavigateAsync(nameof(ResetPasswordPage), parameters);
                //await NavigationService.NavigateAsync(nameof(LoginPage));
            }
            catch (Exception)
            {
                loading.Hide();
                _userDialogs.Alert("Could not process request");
                //await NavigationService.NavigateAsync(nameof(LoginPage));
            }
        }

        private void SendPasswordResetEmail(string Email, string pass)
        {
            // TODO: Implement email sending logic here

            // Send the email
            SendEmail(Email, pass);

            // Display a message to the user indicating that the email has been sent
            _userDialogs.Alert("An email has been sent with instructions on how to reset your password.", "Email Sent", "OK");
        }

        public static void SendEmail(string Email, string Pass)
        {

            var client = new SendGridClient(App.SendGridApiKey);
            var from = new EmailAddress("marjoe.aguilar18@gmail.com", "FEBC App Stream");
            var subject = "Forgot Password";
            var to = new EmailAddress(Email);
            var plainTextContent = "Reset Password link";
            var htmlContent =
              $"<strong> " +
                    $" Hi, {Email}." +
                    $" <br><br><br> " +
                    $"Thank you for using your FEBC App forgot password. " +
                    $"<br><br><br>" +
                    $" This is your new password: {Pass}" +
                    $" <br> " +
                    $"Enjoy!" +
                    $"<br><br><br>" +
                    $" Regards," +
                    $"<br>" +
                    $"Team FEBC" +
                    $"</strong>";
            var message = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response1 = client.SendEmailAsync(message);
        }

        private async void Terms()
        {
            await Launcher.OpenAsync(new Uri("https://febc.ph/terms-and-conditions-of-use/"));
        }

        private void Back()
        {
            NavigationService.GoBackAsync();
        }


        private async Task<string> RegisterUser(LoginDto loginDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(loginDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}auth/login", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;
        }

        private UserData ParseResponse(string response)
        {
            return JsonConvert.DeserializeObject<UserData>(response);
        }

    
        #endregion
    }
}
