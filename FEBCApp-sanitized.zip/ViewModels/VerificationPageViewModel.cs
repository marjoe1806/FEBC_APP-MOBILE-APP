﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Helpers;
using FEBCApp.Models;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SendGrid;
using SendGrid.Helpers.Mail;
using Xamarin.Essentials;
using System.Linq;
using System.Timers;
using FEBCApp.Verification;

namespace FEBCApp.ViewModels
{
    class VerificationPageViewModel : BaseNavigationViewModel
    {

        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;

        private DateTime _created;
        private Timer _timer;
        private const int TimeoutSeconds = 60;

        public VerificationPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings) : base(navigationService)
        {

            _userDialogs = userDialogs;
            _appSettings = appSettings;


            BackCommand = new DelegateCommand(Back);
            VerifyCommand = new DelegateCommand(Reset);
            ResendCommand = new DelegateCommand(Resend);
        }

       

        public ICommand ResendCommand { get; private set; }
        public ICommand VerifyCommand { get; private set; }
        public ICommand BackCommand { get; private set; }

        private string _verifyCode;
        public string VerifyCode
        {
            get => _verifyCode;
            set => SetProperty(ref _verifyCode, value);
        }

        private string _code;
        public string Code
        {
            get => _code;
            set => SetProperty(ref _code, value);
        }


        private async void Back()
        {
            await NavigationService.NavigateAsync(nameof(LoginPage));
        }

        private async void Reset()
        {
            var loading = _userDialogs.Loading("Please wait...");
            //_userDialogs.Alert(Settings2.ForgotPassEmail);
            //_userDialogs.Alert(VerificationCode.Code);
           // _userDialogs.Alert(_appSettings.Username);

            try
            {
                if (string.IsNullOrEmpty(VerifyCode))
                {
                    _userDialogs.Alert("Verification Code is required!");

                    loading.Hide();
                    return;
                }

                _created = DateTime.Now;
                _timer = new Timer(TimeoutSeconds * 1000);
                _timer.Elapsed += OnTimedEvent;
                _timer.AutoReset = false;
                _timer.Enabled = true;

                 
                   

                if (VerificationCode.Code == VerifyCode)
                {
                    loading.Hide();
                    await NavigationService.NavigateAsync(nameof(ResetPasswordPage));
                }
                else
                {
                    loading.Hide();
                    //await NavigationService.NavigateAsync($"{nameof(HomePage)}");
                    await _userDialogs.AlertAsync("Oops! The verification code you entered is incorrect. Please try again.");
                }


            }
            catch (Exception)
            {
                loading.Hide();
                //await NavigationService.NavigateAsync($"{nameof(HomePage)}");
                await _userDialogs.AlertAsync("Could not process request");
            }

        }

        private void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            // Delete the verification code from storage
            VerificationCode.Code = "0";
        }

        private async void Resend()
        {
            var b = await getApiData(Settings2.ForgotPassEmail);
            var name = b.Firstname + " " + b.Lastname;


            var loading = _userDialogs.Loading("Please wait...");
            VerificationCode.Code = GenerateVerificationCode(6);
            _userDialogs.Loading(Settings2.ForgotPassEmail);
            var client = new SendGridClient(App.SendGridApiKey);
            var from = new EmailAddress("marjoe.aguilar18@gmail.com", "FEBC App Stream");
            var subject = "Your One - Time Password(OTP) for Password Reset";
            var to = new EmailAddress(Settings2.ForgotPassEmail);
            var plainTextContent = "Reset Password link";
            var htmlContent =
              $"<strong> " +
                    $" Dear {  name  }," +
                    $" <br><br><br> " +
                    $"We have received a request to reset your FEBC PH STREAM account password. To do this, please enter the OTP below:" +
                    $"<br><br><br>" +
                    $"<b>{VerificationCode.Code}</b>" +
                    $"<br><br><br>" +
                    $"If you did not initiate this request, please disregard this email." +
                    $"<br><br><br>" +
                    $" Regards," +
                    $"<br>" +
                    $"Team FEBC" +
                    $"</strong>";
            var message = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response1 = client.SendEmailAsync(message);

            loading.Hide();
            //await NavigationService.NavigateAsync($"{nameof(HomePage)}");
            await _userDialogs.AlertAsync("Verification code sent.");
        }


        public string GenerateVerificationCode(int length)
        {
            const string digits = "0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(digits, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public static void SendEmail(string email)
        {

            var client = new SendGridClient(App.SendGridApiKey);
            var from = new EmailAddress("marjoe.aguilar18@gmail.com", "FEBC App Stream");
            var subject = "Verification Complete";
            var to = new EmailAddress(email);
            var plainTextContent = "Reset Password link";
            var htmlContent =
              $"<strong> " +
                    $" Hi, {email}." +
                    $" <br><br><br> " +
                    $"Thank you for completing your FEBC PH STREAM reset password. " +
                    $"<br><br><br> " +
                    $"This email confirms that you have successfully reset your password. You can now enter your new password." +
                    $"<br><br><br> " +
                    $"Enjoy!" +
                    $"<br><br><br> " +
                    $" Regards," +
                    $"<br>" +
                    $"Team FEBC" +
                    $"</strong>";
            var message = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response1 = client.SendEmailAsync(message);
            

        }

        public async Task<UserData> getApiData(string email)
        {
            var httpClient = new HttpClient();
            var json = await httpClient.GetStringAsync($"{ApiConstants.BaseUrl}user/get-email/" + email);
            UserData userdetails = JsonConvert.DeserializeObject<UserData>(json);

            return userdetails;

        }

        private async Task<string> Reset(ResetPassDto resetPassDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(resetPassDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}user/update-password/{Settings2.UserId}", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;

        }


        private RegistrationResponse ParseUpdateData(string response)
        {
            //_userDialogs.Alert(response, "OK");
            return JsonConvert.DeserializeObject<RegistrationResponse>(response);
        }
    }
}

