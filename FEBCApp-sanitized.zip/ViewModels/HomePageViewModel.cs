﻿using Acr.UserDialogs;
using FEBCApp.Helpers;
using FEBCApp.Models;
using FEBCApp.Services.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using ImTools;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Prism.Commands;
using Prism.Navigation;
using Prism.Navigation.Xaml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.Tracing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace FEBCApp.ViewModels
{
    public class HomePageViewModel : BaseNavigationViewModel
    {
        private readonly IUserDialogs _userDialogs;

        [Obsolete]
        public HomePageViewModel(INavigationService navigationService, IUserDialogs userDialogs) : base(navigationService)
        {
            _userDialogs = userDialogs;

          
            FacebookImageCommand = new DelegateCommand(FacebookImage);
            MessageImageCommand = new DelegateCommand(MessageImage);
          
            BrowseWebCommand = new DelegateCommand(BrowseWeb);
         
            ShareImageCommand = new DelegateCommand(ShareImage);
            PlayCommand = new DelegateCommand(Play);
            PauseCommand = new DelegateCommand(Pause);
            StopCommand = new DelegateCommand(Stop);
            PreviousCommand = new DelegateCommand(Previous);
            NextCommand = new DelegateCommand(Next);
            DataChangedCommand = new DelegateCommand(DataChange);
            CloseShareDialogCommand = new DelegateCommand(CloseShareDialog);
            FacebookShareCommand = new DelegateCommand(FacebookShare);
            MessengerShareCommand = new DelegateCommand(MessengerShare);
            TwitterShareCommand = new DelegateCommand(TwitterShare);
            ViberShareCommand = new DelegateCommand(ViberShare);
            WhatsAppShareCommand = new DelegateCommand(WhatsAppShare);
            CopyLinkCommand = new DelegateCommand(CopyLink);

            TouchCommand = new Command(async () => await Touch());
            ProfileImageCommand = new Command(async () => await ProfileImage());
            HandshakeImageCommand = new Command(async () => await HandshakeImage());
        }

        public override void OnNavigatedTo(INavigationParameters parameters)
        {
            if (parameters.GetNavigationMode() == Prism.Navigation.NavigationMode.Back)
                return;

            SetDefaults();
        }

        #region Bindable Commands
        public ICommand TouchCommand { get; private set; }
        public ICommand FacebookImageCommand { get; private set; }
        public ICommand MessageImageCommand { get; private set; }
        public ICommand BrowseWebCommand { get; private set; }
        public ICommand HandshakeImageCommand { get; private set; }
        public ICommand DonationPageCommand { get; }
        public ICommand DonationPage2Command { get; }
        public ICommand ShareImageCommand { get; private set; }
        public ICommand ProfileImageCommand { get; private set; }
        public ICommand PlayCommand { get; private set; }
        public ICommand StopCommand { get; private set; }
        public ICommand PauseCommand { get; private set; }
        public ICommand DataChangedCommand { get; private set; }
        public ICommand PreviousCommand { get; private set; }
        public ICommand NextCommand { get; private set; }
        public ICommand CloseShareDialogCommand { get; private set; }
        public ICommand FacebookShareCommand { get; private set; }
        public ICommand MessengerShareCommand { get; private set; }
        public ICommand TwitterShareCommand { get; private set; }
        public ICommand ViberShareCommand { get; private set; }
        public ICommand WhatsAppShareCommand { get; private set; }
        public ICommand CopyLinkCommand { get; private set; }
        #endregion

        #region Bindable Properties
        private ObservableCollection<Station> _radioList;
        public ObservableCollection<Station> RadioList
        {
            get => _radioList;
            set => SetProperty(ref _radioList, value);
        }

        private bool _displayPlay;
        public bool DisplayPlay
        {
            get => _displayPlay;
            set => SetProperty(ref _displayPlay, value);
        }

        private bool _displayPauseStop;
        public bool DisplayPauseStop
        {
            get => _displayPauseStop;
            set => SetProperty(ref _displayPauseStop, value);
        }

        private bool _isPlaying;
        public bool IsPlaying
        {
            get => _isPlaying;
            set => SetProperty(ref _isPlaying, value);
        }

        private string _count;
        public string Count
        {
            get => _count;
            set => SetProperty(ref _count, value);
        }

        private bool _isPreviousVisible;
        public bool IsPreviousVisible
        {
            get => _isPreviousVisible;
            set => SetProperty(ref _isPreviousVisible, value);
        }

        private bool _isNextVisible;
        public bool IsNextVisible
        {
            get => _isNextVisible;
            set => SetProperty(ref _isNextVisible, value);
        }

        private bool _shareDialogShown;
        public bool ShareDialogShown
        {
            get => _shareDialogShown;
            set => SetProperty(ref _shareDialogShown, value);
        }
        #endregion

        #region Methods
        private void SetDefaults()
        {
            Count = "0";
            ShareDialogShown = false;
            IsPreviousVisible = false;
            IsNextVisible = true;
            RadioList = new ObservableCollection<Station>(StationHelper.GetRadioStation());
            Play();
        }

        private void Previous()
        {
            if (Count == "0")
                IsPreviousVisible = false;

            int parsedCount = Convert.ToInt32(Count) - 1;

            Count = parsedCount.ToString();
        }

        private void Next()
        {
            string lastRecord = RadioList.LastOrDefault().Count;

            if (Count == lastRecord)
                IsNextVisible = false;

            int parsedCount = Convert.ToInt32(Count) + 1;

            Count = parsedCount.ToString();
        }

        private void CloseShareDialog()
        {
            ShareDialogShown = false;
        }

        private async void FacebookShare()
        {
            string facebookShareLink = "https://www.facebook.com/sharer/sharer.php?u=";
            //string facebookShareLink = "https://www.facebook.com/FEBCPH/"; 
            string appLink = "https://play.google.com/store/apps/details?id=com.fourello.febcphstream";

            await Browser.OpenAsync($"{facebookShareLink}{HttpUtility.UrlEncode(appLink)}", BrowserLaunchMode.SystemPreferred);
        }

        [Obsolete]
        private async void MessengerShare()
        {
            
                var shareLink = "https://play.google.com/store/apps/details?id=com.fourello.febcphstream";
                var uri = new Uri($"fb-messenger://share/?link={HttpUtility.UrlEncode(shareLink)}");
                await Launcher.OpenAsync(uri);

           

        }

        private async void TwitterShare()
        {
            string twitterShareLink = "https://twitter.com/intent/tweet?text=";
            string appLink = "https://play.google.com/store/apps/details?id=com.fourello.febcphstream";

            await Browser.OpenAsync($"{twitterShareLink}{HttpUtility.UrlEncode(appLink)}", BrowserLaunchMode.SystemPreferred);
            //await Share.RequestAsync($"{twitterShareLink}{HttpUtility.UrlEncode(appLink)}");
        }

        [Obsolete]
        private async void ViberShare()
        {
            try
            {
                var shareLink = "https://play.google.com/store/apps/details?id=com.fourello.febcphstream";
                var uri = new Uri($"viber://forward?text={HttpUtility.UrlEncode(shareLink)}");
                await Launcher.OpenAsync(uri);


            }
            catch (Exception)
            {
                Device.OpenUri(new Uri("https://play.google.com/store/apps/details?id=com.viber.voip"));
            }

        }

        [Obsolete]
        private async void WhatsAppShare()
        {

            try
            {
                var shareLink = "https://play.google.com/store/apps/details?id=com.fourello.febcphstream";
                var uri = new Uri($"whatsapp://send?text={HttpUtility.UrlEncode(shareLink)}");
                await Launcher.OpenAsync(uri);

               
            }
            catch (Exception)
            {
                Device.OpenUri(new Uri("https://play.google.com/store/apps/details?id=com.whatsapp"));
            }
        }

        private async void CopyLink()
        {
            await Clipboard.SetTextAsync("https://play.google.com/store/apps/details?id=com.fourello.febcphstream");
            _userDialogs.Toast("Copied to clipboard.", TimeSpan.FromSeconds(2));
        }

        private async void MessageImage()
        {
            string messengerLink = RadioList.FirstOrDefault(x => x.Count.Equals(Count)).MessengerLink;

            await Browser.OpenAsync(messengerLink, BrowserLaunchMode.SystemPreferred);
        }

        private async Task Touch()
        {
            await NavigationService.NavigateAsync(nameof(AboutPage));
        }

        private async Task ProfileImage()
        {
            await NavigationService.NavigateAsync(nameof(ProfilePage));
        }

        private async Task HandshakeImage()
        {
            await NavigationService.NavigateAsync(nameof(DonationPage));
        }

        private async void FacebookImage()
        {
            string facebookLink = RadioList.FirstOrDefault(x => x.Count.Equals(Count)).FacebookLink;

            await Browser.OpenAsync(facebookLink, BrowserLaunchMode.SystemPreferred);
        }

        public async void BrowseWeb()
        {
            await Launcher.OpenAsync(new Uri("https://febc.ph/"));
            //await Browser.OpenAsync("https://febc.ph/", BrowserLaunchMode.SystemPreferred);
        }
     


        public void ShareImage()
        {
            //await Share.RequestAsync(new ShareTextRequest
            //{
            //    Uri = "https://play.google.com/store/apps/details?id=com.fourello.febcphstream"
            //});
            ShareDialogShown = true;
        }

        public void DataChange()
        {
            IsPreviousVisible = Count != "0";
            IsNextVisible = Count != RadioList.LastOrDefault().Count;

            Device.BeginInvokeOnMainThread(() =>
            {
                Stop();
                if (DisplayPauseStop)
                {
                    IsPlaying = false;
                    DisplayPauseStop = false;
                    DisplayPlay = true;
                }

                switch (Count)
                {
                    case "0":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dzas");
                        break;
                    case "1":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dzfe");
                        break;
                    case "2":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/nowxd");
                        break;
                    case "3":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_pcon");
                        break;
                    case "4":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dway");
                        break;
                    case "5":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dxki");
                        break;
                    case "6":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dyfr");
                        break;
                    case "7":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dxfe");
                        break;
                    case "8":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dyvs");
                        break;
                    case "9":
                        DependencyService.Get<IStreamService>().Play("http://ph-icecast-win.eradioportal.com:8000/dxjl");
                        break;
                    case "10":
                        DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dzmr");
                        break;
                }

                IsPlaying = true;
                DisplayPauseStop = true;
                DisplayPlay = false;
            });
        }

        public void Play()
        {


            switch (Count)
            {
                case "0":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dzas");
                    break;
                case "1":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dzfe");
                    break;
                case "2":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/nowxd");
                    break;
                case "3":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_pcon");
                    break;
                case "4":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dway");
                    break;
                case "5":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dxki");
                    break;
                case "6":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dyfr");
                    break;
                case "7":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dxfe");
                    break;
                case "8":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dyvs");
                    break;
                case "9":
                    DependencyService.Get<IStreamService>().Play("http://ph-icecast-win.eradioportal.com:8000/dxjl");
                    break;
                case "10":
                    DependencyService.Get<IStreamService>().Play("http://sg-icecast.eradioportal.com:8000/febc_dzmr");
                    break;

            }

            IsPlaying = true;
            DisplayPauseStop = true;
            DisplayPlay = false;
        }

        private void Pause()
        {
            DependencyService.Get<IStreamService>().Pause();
            IsPlaying = false;
            DisplayPauseStop = false;
            DisplayPlay = true;
        }

        private void Stop()
        {
            DependencyService.Get<IStreamService>().Stop();
            IsPlaying = false;
            DisplayPauseStop = false;
            DisplayPlay = true;
        }
        #endregion

    }
}