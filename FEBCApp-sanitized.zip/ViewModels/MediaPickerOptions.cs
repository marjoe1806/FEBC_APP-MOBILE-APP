﻿using Plugin.Media.Abstractions;

namespace FEBCApp.ViewModels
{
    internal class MediaPickerOptions : PickMediaOptions
    {
        public string Title { get; set; }
    }
}