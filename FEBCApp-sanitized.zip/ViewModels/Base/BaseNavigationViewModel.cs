﻿using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.ViewModels.Base
{

    public class BaseNavigationViewModel : BaseViewModel
    {
        protected INavigationService NavigationService;

        public BaseNavigationViewModel(INavigationService navigationService)
        {
            NavigationService = navigationService;
        }

      
    }
}
