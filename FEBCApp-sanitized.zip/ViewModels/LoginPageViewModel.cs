﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Models;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Text.RegularExpressions;
using Xamarin.Essentials;
using Xamarin.Forms;
using FEBCApp.Verification;
using SendGrid;
using SendGrid.Helpers.Mail;
using FEBCApp.Helpers;
using Newtonsoft.Json.Linq;
using System.Web;
using System.Linq;

namespace FEBCApp.ViewModels
{
    public class LoginPageViewModel : BaseNavigationViewModel
    {
        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;

        public LoginPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;

            LoginCommand = new DelegateCommand(Login);
            RegisterCommand = new DelegateCommand(Register);
            ForgotPasswordCommand = new DelegateCommand(ForgotPassword);
        }



        #region Bindable Commands
        public ICommand LoginCommand { get; set; }
        public ICommand RegisterCommand { get; set; }
        public ICommand ForgotPasswordCommand { get; set; }
        #endregion

        #region Bindable Properties
        private string _email;
        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }

        private string _password;
        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }
        #endregion
        
        #region Methods
        private async void Login()
        {
            var loading = _userDialogs.Loading("Please wait...");

            try
            {
                if (string.IsNullOrEmpty(Email))
                {
                    _userDialogs.Alert("Email is required!");

                    loading.Hide();
                    return;
                }

                if (string.IsNullOrEmpty(Password))
                {
                    _userDialogs.Alert("Password is required!");

                    loading.Hide();
                    return;
                }

                LoginDto loginDto = new LoginDto();
                loginDto.Email = Email;
                loginDto.Password = Password;

                //else

                //LoginDto loginDto = new LoginDto();
                //loginDto.Username = Email;
                //loginDto.Password = Password;

                string response = await Authenticate(loginDto);
                //var token = JObject.Parse(response)["token"].Value<string>();
                UserData userData = GetUserData(response);
                var a = await getApiData(Email);
                //_userDialogs.Alert(IP.IpAddress.GetIPAddress(), "Ok");

                //var c = FEBCApp.IP.IpAddress.GetIPAddress();
               // Token.TokenKey = token;


                if (!userData.Message.Contains("Successfully logged in"))
                {
                    loading.Hide();
                    _userDialogs.Alert("Incorrect username or password!");
                    return;
                }

                _appSettings.IsAuthenticated = true;
                _appSettings.FirstName = a.Firstname;
                _appSettings.LastName = a.Lastname;
                _appSettings.Gender = a.Gender;
                _appSettings.AgeRange = a.Age;
                _appSettings.Country = a.Country;
                _appSettings.City = a.City;
                _appSettings.Id = a.Id;
                _appSettings.Usertype = "public";

                //_appSettings.Avatar = $"{ApiConstants.BaseUrl}{userData.Avatar}";

                loading.Hide();
                await _userDialogs.AlertAsync("You're in! Enjoy listening.");
                await NavigationService.NavigateAsync($"{nameof(HomePage)}");
            }
            catch (Exception)
            {
                loading.Hide();
                //await NavigationService.NavigateAsync($"{nameof(HomePage)}");
                await _userDialogs.AlertAsync("Could not process request");
            }
        }

        public async Task<UserData> getApiData(string email)
        {
            var httpClient = new HttpClient();
            var json = await httpClient.GetStringAsync($"{ApiConstants.BaseUrl}user/get-email/" + email);
            UserData userdetails = JsonConvert.DeserializeObject<UserData>(json);

            return userdetails;

        }
        private void DisplayAlert(global::System.String v1, global::System.String v2, global::System.String v3)
        {
        }

        private async void ForgotPassword()
        {
            var promptResult = await _userDialogs.PromptAsync("Enter email address", "", "Send");
           
            if (promptResult.Ok && !string.IsNullOrWhiteSpace(promptResult.Value))
            {
                // Use the user's input value
                string email = promptResult.Value;
                var loading = _userDialogs.Loading("Please wait...");
                //_userDialogs.Alert(email);
                if (IsValidEmail(email))
                {
                  

                    try
                    {
                        
                        var b = await getApiData(email);
                        var name = b.Firstname + " " + b.Lastname;
                        //_userDialogs.Alert(b.Id);
                        if (b.Id != null) {
                            string verificationCode = GenerateVerificationCode(6);
                            SendPasswordResetEmail(email, verificationCode, name);
                            loading.Hide();

                            _appSettings.IsAuthenticated = true;
                            _appSettings.FirstName = b.Firstname;
                            _appSettings.LastName = b.Lastname;
                            _appSettings.Gender = b.Gender;
                            _appSettings.AgeRange = b.Age;
                            _appSettings.Country = b.Country;
                            _appSettings.City = b.City;
                            _appSettings.Id = b.Id;
                            _appSettings.Usertype = "public";

                            Settings2.UserId = b.Id;
                            VerificationCode.Code = verificationCode;
                            Settings2.ForgotPassEmail = b.Username;
                            await NavigationService.NavigateAsync(nameof(VerificationPage));
                            //await NavigationService.NavigateAsync(nameof(LoginPage));

                            
                        }

                    }
                    catch (Exception)
                    {
                        loading.Hide();
                        _userDialogs.Alert("We cannot see your email address. Try another one.","Sorry");
                        //await NavigationService.NavigateAsync(nameof(LoginPage));
                    }


                }
                else
                {
                    // Display an error message
                    _userDialogs.Alert("Please enter a valid email address.", "Error", "OK");
                }
            }


            //Launcher.OpenAsync(new Uri("mailto:febcph.tech@gmail.com"));
            //NavigationService.NavigateAsync(nameof(ForgotPasswordPage));
            //_userDialogs.AlertAsync("Oppzzz.. Sorry!!","Under Maintainance!!");

        }

        public string GenerateVerificationCode(int length)
        {
            const string digits = "0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(digits, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void SendPasswordResetEmail(string email, string verificationCode, string name)
        {
            // TODO: Implement email sending logic here
          

            
            // Send the email
            SendEmail(email, verificationCode, name);

            // Display a message to the user indicating that the email has been sent
            _userDialogs.Alert("Verification code has been sent. Please check your email address.", "Verification Code Sent", "OK");
        }

        public static void SendEmail(string email, string verificationCode, string name)
        {
            
            var client = new SendGridClient(App.SendGridApiKey);
            var from = new EmailAddress("marjoe.aguilar18@gmail.com", "FEBC PH Stream");
            var subject = "Your One-Time Password (OTP) for Password Reset";
            var to = new EmailAddress(email);
            var plainTextContent = "Reset Password link";
            var htmlContent =
              $"<strong> " +
                    $" Dear {name}," +
                    $" <br><br><br> " +
                    $"We have received a request to reset your password for your account. To proceed with the password reset process, please enter the following OTP code: " +
                    $"<br><br><br>" +
                    $"{verificationCode}" +
                    $"<br><br><br>" +
                    $"Please enter this OTP code in the designated field to complete the password reset process. Please note that this OTP is valid for only one minute and can only be used once. " +
                    $"<br><br><br>" +
                    $"Best regards, " +
                    $"<br>" +
                    $"FEBC PH Stream" +
                    $"</strong>";
            var message = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response1 = client.SendEmailAsync(message);
        }


        private async Task<string> Reset(LoginDto loginDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(loginDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}auth/login", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;
        }

        private bool IsValidEmail(string email)
        {
            // Define a regular expression pattern for a valid email address
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            // Use the Regex class to check if the email matches the pattern
            Regex regex = new Regex(pattern);
            return regex.IsMatch(email);
        }
        private void Register()
        {
            NavigationService.NavigateAsync(nameof(SignupPage));
        }

        private async Task<string> Authenticate(LoginDto loginDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(loginDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}auth/login", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;
        }

        private UserData GetUserData(string response)
        {
            return JsonConvert.DeserializeObject<UserData>(response);
        }
        #endregion
    }

}
