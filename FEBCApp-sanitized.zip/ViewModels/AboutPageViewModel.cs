﻿using FEBCApp.ViewModels.Base;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;

namespace FEBCApp.ViewModels
{
    public class AboutPageViewModel : BaseNavigationViewModel
    {
        public AboutPageViewModel(INavigationService navigationService) : base(navigationService)
        {
            BackCommand = new DelegateCommand(Back);
        }

        #region Bindable Commands
        public ICommand BackCommand { get; private set; }
        #endregion

        #region Methods
        public void Back()
        {
            NavigationService.GoBackAsync();
        }
        #endregion
    }
}
