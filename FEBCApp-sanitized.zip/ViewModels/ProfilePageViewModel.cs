﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Models;
using FEBCApp.Services.Base;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using FFImageLoading;
using ImTools;
using FEBCApp.Helpers;
using Newtonsoft.Json;
using Plugin.Media.Abstractions;
using Prism.Commands;
using Prism.Navigation;
using SendGrid.Helpers.Mail.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Newtonsoft.Json.Linq;

namespace FEBCApp.ViewModels
{
    public class ProfilePageViewModel : BaseNavigationViewModel
    {
        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;
        private readonly IMedia _media;
        private byte[] _takePhotoSource;
        private bool _hasImage;

        public ProfilePageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings, IMedia media) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;
            _media = media;

            SaveCommand = new DelegateCommand(Save);
            ContactTechCommand = new DelegateCommand(ContactTech);
            PickPhotoCommand = new DelegateCommand(PickPhoto);
            LogOutCommand = new DelegateCommand(LogOut);
            BackCommand = new DelegateCommand(Back);
        }

        public override void OnNavigatedTo(INavigationParameters parameters)
        {
            SetDefaults();
        }

        #region Bindable Commands
        public ICommand SaveCommand { get; private set; }
        public ICommand ContactTechCommand { get; private set; }
        public ICommand LogOutCommand { get; private set; }
        public ICommand BackCommand { get; private set; }
        public ICommand PickPhotoCommand { get; private set; }
        #endregion

        #region Bindable Properties
        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set => SetProperty(ref _lastName, value);
        }

        private string _selectedGender;
        public string SelectedGender
        {
            get => _selectedGender;
            set => SetProperty(ref _selectedGender, value);
        }

        private string _selectedAgeRange;
        public string SelectedAgeRange
        {
            get => _selectedAgeRange;
            set => SetProperty(ref _selectedAgeRange, value);
        }

        private string _selectedCountry;
        public string SelectedCountry
        {
            get => _selectedCountry;
            set => SetProperty(ref _selectedCountry, value);
        }

        private string _city;
        public string City
        {
            get => _city;
            set => SetProperty(ref _city, value);
        }

        private ImageSource _pictureSource;
        public ImageSource PictureSource
        {
            get => _pictureSource;
            set => SetProperty(ref _pictureSource, value);
        }
        #endregion

         #region Methods
        private void SetDefaults()
        {


            FirstName = _appSettings.FirstName;
            LastName = _appSettings.LastName;
            SelectedGender = _appSettings.Gender;
            SelectedAgeRange = _appSettings.AgeRange;
            SelectedCountry = _appSettings.Country;
            City = _appSettings.City;



            _hasImage = false;
            ///PictureSource = string.IsNullOrEmpty(_appSettings.Avatar) ? ImageSource.FromFile("user.png") : ImageSource.FromUri(new Uri(_appSettings.Avatar));
            PictureSource = ImageSource.FromFile("user.png");
        }

        private async void PickPhoto()
        {
            string[] options = new string[] { "Take a photo with camera", "Choose a photo from gallery" };

            var action = await _userDialogs.ActionSheetAsync("Add Photo!", "", "Cancel", null, options);

            if (action == "Take a photo with camera")
            {
                // Take a photo using TakePhotoAsync
                if (_media.IsCameraAvailable && _media.IsTakePhotoSupported)
                {
                    try
                    {
                        var takePhoto = await _media.TakePhotoAsync(
                            new StoreCameraMediaOptions
                            {
                                Directory = "FEBC",
                                Name = $"{_appSettings.Id}_PROFILE_PIC.jpg",
                                PhotoSize = PhotoSize.Full,
                                SaveToAlbum = true,
                                DefaultCamera = CameraDevice.Front,
                                CompressionQuality = 92
                            });

                        using (MemoryStream stream = new MemoryStream())
                        {
                            await takePhoto.GetStream().CopyToAsync(stream);
                            _takePhotoSource = stream.ToArray();
                        }

                        PictureSource = ImageSource.FromStream(() => new MemoryStream(_takePhotoSource));
                    }
                    catch (Exception)
                    {
                        //_userDialogs.Alert(ex.Message);
                        PictureSource = ImageSource.FromFile("user.png");
                    }
                }
            }
            else if (action == "Choose a photo from gallery")
            {
                try
                {
                    if (_media.IsPickPhotoSupported)
                    {
                        var pickPhoto = await _media.PickPhotoAsync();
                        using (MemoryStream stream = new MemoryStream())
                        {
                            await pickPhoto.GetStream().CopyToAsync(stream);
                            _takePhotoSource = stream.ToArray();
                        }

                        PictureSource = ImageSource.FromStream(() => new MemoryStream(_takePhotoSource));
                    }
                }
                catch (Exception)
                {
                    //_userDialogs.Alert(ex.Message);
                    PictureSource = ImageSource.FromFile("user.png");
                }
            }
        }



        private async Task<string> UpdateUser(UpdateDto updateDto)
        {
            using (var httpClient = new HttpClient())
            {
                var serializedObject = JsonConvert.SerializeObject(updateDto);
                var httpContent = new StringContent(serializedObject);
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                var result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}user/update/{_appSettings.Id}", httpContent);
                var response = await result.Content.ReadAsStringAsync();

                return response;
            }
        }

        private RegistrationResponse ParseUpdateData(string response)
        {
            return JsonConvert.DeserializeObject<RegistrationResponse>(response);
        }

        private async Task<RegistrationResponse> UploadImage(byte[] stream, string id)
        {
            using (var client = new HttpClient())
            {
                var content = new ByteArrayContent(stream);
                var formData = new MultipartFormDataContent();

                content.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
                {
                    FileName = $"{_appSettings.Id}_PROFILE_PIC.jpg",
                    Name = "avatar"
                };
                content.Headers.ContentType = new MediaTypeHeaderValue("image/jpg");

                formData.Add(content);

                try
                {
                    var uploadResult = await client.PostAsync($"{ApiConstants.BaseUrl}uploadimage/{id}", formData);
                    var uploadResponse = await uploadResult.Content.ReadAsStringAsync();

                    return JsonConvert.DeserializeObject<RegistrationResponse>(uploadResponse);
                }
                catch (Exception)
                {
                    return new RegistrationResponse();
                }
            }
        }

        public async Task<UserData> GetApiData(string email)
        {
            using (var httpClient = new HttpClient())
            {
                var json = await httpClient.GetStringAsync($"{ApiConstants.BaseUrl}user/get-email/{email}");
                UserData userDetails = JsonConvert.DeserializeObject<UserData>(json);

                return userDetails;
            }
        }


        private async void ContactTech()
        {
            await Launcher.OpenAsync(new Uri("mailto:febcph.tech@gmail.com"));
        }

        private async void LogOut()
        {
            var check = await _userDialogs.ConfirmAsync("Are you sure you want to logout?", "", "Yes", "No");
            if (check)
            {
                _appSettings.FlushSession();
                DependencyService.Get<IStreamService>().Pause();
                DependencyService.Get<IStreamService>().Stop();
                await NavigationService.NavigateAsync($"app:///{nameof(LoginPage)}");
            }
        }

        private void Back()
        {
            NavigationService.GoBackAsync();
        }

        private async void Save()
        {
            if (string.IsNullOrEmpty(FirstName))
            {
                _userDialogs.Alert("First Name is required!");
                return;
            }

            if (string.IsNullOrEmpty(LastName))
            {
                _userDialogs.Alert("Last Name is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedGender))
            {
                _userDialogs.Alert("Gender is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedAgeRange))
            {
                _userDialogs.Alert("Age is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedCountry))
            {
                _userDialogs.Alert("Country is required!");
                return;
            }

            if (string.IsNullOrEmpty(City))
            {
                _userDialogs.Alert("City is required!");
                return;
            }

            var loading = _userDialogs.Loading("Please wait...");

            try
            {
                UpdateDto updateDto = new UpdateDto
                {
                    FirstName = FirstName,
                    LastName = LastName,
                    Gender = SelectedGender,
                    Age = SelectedAgeRange,
                    Country = SelectedCountry,
                    City = City,
                    Usertype = "public"
                };

                string result = await UpdateUser(updateDto);
                RegistrationResponse response = ParseUpdateData(result);
                var message = JObject.Parse(result)["message"].Value<string>();

                if (message == "Successfully updated user information.")
                {
                    loading.Hide();
                    DependencyService.Get<IStreamService>().Pause();
                    _userDialogs.Alert("To see your profile updates, please re-log in.", "Update complete!", "OK");
                    await NavigationService.NavigateAsync(nameof(HomePage));
                }

                var userDetails = await GetApiData(_appSettings.Username);
                _appSettings.FirstName = userDetails.Firstname;
                _appSettings.LastName = userDetails.Lastname;
                _appSettings.Gender = userDetails.Gender;
                _appSettings.AgeRange = userDetails.Age;
                _appSettings.Country = userDetails.Country;
                _appSettings.City = userDetails.City;
                _appSettings.Id = userDetails.Id;
                _appSettings.Usertype = "public";
            }
            catch (Exception)
            {
                loading.Hide();
                // Handle exception or show appropriate error message
            }
        }

        #endregion
    }
}
