﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Helpers;
using FEBCApp.Models;
using FEBCApp.Services.Cybersource;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Services;
using FEBCApp.Views;
using FFImageLoading;
using Newtonsoft.Json;
using Plugin.Media.Abstractions;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using System.Security.Cryptography;
using System.Web;
using Windows.ApplicationModel.Payments;
using Windows.Web.Http;
using static FEBCApp.ViewModels.HandshakePageViewModel;

namespace FEBCApp.ViewModels
{
    public class HandshakePageViewModel : BaseNavigationViewModel
    {
        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;
        // private readonly IMedia _media;
        //private byte[] _takePhotoSource;
        //private bool _hasImage;
        private const string CyberSourceCheckoutUrl = "https://secureacceptance.cybersource.com/checkout/";
        private const string MerchantId = "006010000017694";
        private const string ProfileId = "5ACE8595-AB61-438C-9574-44A0C33C68AF";
        private const string UnionBankApiEndpoint = "https://api-uat.unionbankph.com/partners/sb/online/v1/payments/single";
        private const string AccessKey = "e6f3bb1de8c0341bad37d79f84e6cd3d";
        private const string SecretKey = "1b92507b6eb3423e8e0339095657558c45f7c14ad7fb4387b59615ffbd2b6ad47cb6a565bb1b4f769c1a5290b06ba563ab7ff408335d4c30885c4bde242e04ce9558165222d5485cbbdc60d8130c6e21b97f80e2509f4d22b7e1b9735fc4e18555022ce883084f0d846a155a3e3511041f8da6bedeea482a9294b48333e85364";


        public HandshakePageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings, IMedia media) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;
            // _media = media;


            ConfirmCommand = new DelegateCommand(Confirm);
            BackCommand = new DelegateCommand(Back);

            var fname = _appSettings.FirstName + " " + _appSettings.LastName;
            _userDialogs.AlertAsync($"Hi, {fname} currently our avaible payment gateway is Union Bank only.");

        }


        #region Bindable Commands
        public ICommand ConfirmCommand { get; private set; }
        public ICommand BackCommand { get; private set; }

        #endregion

  

        private bool _unionBank = true; // Set UnionBank as default checked
        public bool UnionBank
        {
            get => _unionBank;
            set
            {
                if (SetProperty(ref _unionBank, value))
                {
                    if (value)
                    {
                        Gcash = false;
                        BPI = false;
                        Maya = false;
                        SelectedColor = Color.Green; // set the color to green
                    }
                    else
                    {
                        SelectedColor = Color.Default; // set the color back to the default color
                    }
                }
            }
        }

        private bool _gcash;
        public bool Gcash
        {
            get => _gcash;
            set
            {
                if (SetProperty(ref _gcash, value))
                {
                    if (value)
                    {
                        UnionBank = false;
                        BPI = false;
                        Maya = false;
                        SelectedColor = Color.Green; // set the color to green

                        // Display "Under Maintenance" message instead of alert
                        ShowUnderMaintenanceMessage();
                    }
                    else
                    {
                        SelectedColor = Color.Default; // set the color back to the default color
                    }
                }
            }
        }

        private bool _bpi;
        public bool BPI
        {
            get => _bpi;
            set
            {
                if (SetProperty(ref _bpi, value))
                {
                    if (value)
                    {
                        Gcash = false;
                        UnionBank = false;
                        Maya = false;
                        SelectedColor = Color.Green; // set the color to green

                        // Display "Under Maintenance" message instead of alert
                        ShowUnderMaintenanceMessage();
                    }
                    else
                    {
                        SelectedColor = Color.Default; // set the color back to the default color
                    }
                }
            }
        }

        private bool _maya;
        public bool Maya
        {
            get => _maya;
            set
            {
                if (SetProperty(ref _maya, value))
                {
                    if (value)
                    {
                        Gcash = false;
                        UnionBank = false;
                        BPI = false;
                        SelectedColor = Color.Green; // set the color to green

                        // Display "Under Maintenance" message instead of alert
                        ShowUnderMaintenanceMessage();
                    }
                    else
                    {
                        SelectedColor = Color.Default; // set the color back to the default color
                    }
                }
            }
        }

        // Method to show "Under Maintenance" message
        private async void ShowUnderMaintenanceMessage()
        {
            await _userDialogs.AlertAsync( "This feature is currently under maintenance.", "Under Maintenance", "OK");
        }

        // Rest of the code...



        private Color _selectedColor = Color.Green;
        public Color SelectedColor
        {
            get => _selectedColor;
            set => SetProperty(ref _selectedColor, value);
        }

        [Obsolete]
        private void Confirm()
        {
            var loading = _userDialogs.Loading("Please wait...");

            if (Gcash)
            {
                _userDialogs.Alert("Gcash payment gateway is under maintainance.", "Sorry", "OK");
                return;
            }

            if (UnionBank)
            {
               

                var checkoutUrl = "https://buy.stripe.com/test_28o5o62Mrfs92zueUU";
                Device.OpenUri(new Uri(checkoutUrl));
                loading.Hide();


             }

            if (BPI)
            {
                _userDialogs.Alert("BPI payment gateway is under maintainance.", "Sorry", "OK");
                loading.Hide();
                return;
            }

            if (Maya)
            {
                _userDialogs.Alert("MAYA payment gateway is under maintainance.", "Sorry", "OK");
                loading.Hide();
                return;
            }


            //NavigationService.GoBackAsync();
            if (!Gcash && !BPI && !UnionBank && !Maya) {
                _userDialogs.Alert("Please select payment gateway.");
                loading.Hide();
                return;
            }

        }


        public class DonationResponse
        {
            public bool Success { get; set; }
            public string DonationId { get; set; }
            public string Message { get; set; }
            public string CheckoutUrl { get; set; }
            // Add other properties for the donation response as needed
            // ...
        }



        private void Back()
        {
            NavigationService.GoBackAsync();
        }
    }
}
