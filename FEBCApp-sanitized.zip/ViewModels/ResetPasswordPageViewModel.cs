﻿using Acr.UserDialogs;
using FEBCApp.Constants;
using FEBCApp.Helpers;
using FEBCApp.Models;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using SendGrid;
using SendGrid.Helpers.Mail;
using Xamarin.Essentials;

namespace FEBCApp.ViewModels
{
    class ResetPasswordPageViewModel : BaseNavigationViewModel
    {

        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;

        public ResetPasswordPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings) : base(navigationService)
        {

            _userDialogs = userDialogs;
            _appSettings = appSettings;


            BackCommand = new DelegateCommand(Back);
            ResetCommand = new DelegateCommand(Reset);

        }


        public ICommand ResetCommand { get; private set; }
        public ICommand BackCommand { get; private set; }

        private string _newPassword;
        public string NewPassword
        {
            get => _newPassword;
            set => SetProperty(ref _newPassword, value);
        }

        private string _confirmPassword;
        public string ConfirmPassword
        {
            get => _confirmPassword;
            set => SetProperty(ref _confirmPassword, value);
        }

        private async void Back()
        {
            await NavigationService.NavigateAsync(nameof(LoginPage));
        }

        private async void Reset()
        {
            var loading = _userDialogs.Loading("Please wait...");

            try
            {
                if (string.IsNullOrEmpty(NewPassword))
                {
                    _userDialogs.Alert("New password is required!");

                    loading.Hide();
                    return;
                }

                if (string.IsNullOrEmpty(ConfirmPassword))
                {
                    _userDialogs.Alert("Confirm password is required!");

                    loading.Hide();
                    return;
                }

                if (NewPassword == ConfirmPassword) {
                    ResetPassDto resetPassDto = new ResetPassDto
                    {
                        Password = NewPassword
                    };

                    string result = await Reset(resetPassDto);
                    RegistrationResponse response = ParseUpdateData(result);
                    //called email function

                    //_userDialogs.Alert(_appSettings.Id);
                    //called api function
                    var a = await getApiData(_appSettings.Id);
                    //_userDialogs.Alert(a.Id, "Ok");

                    string email = a.Username;
                    string name = a.Firstname + " " + a.Lastname;
                    SendEmail(email, name);
                    //_userDialogs.Alert(email, "Ok");

                    loading.Hide();
                    _userDialogs.Alert("You're all set! Your password has been updated.");
                    await NavigationService.NavigateAsync($"{nameof(LoginPage)}");
                }
                else {
                    loading.Hide();
                    //await NavigationService.NavigateAsync($"{nameof(HomePage)}");
                    await _userDialogs.AlertAsync("Password does not match!");
                }

               
            }
            catch (Exception)
            {
                loading.Hide();
                //await NavigationService.NavigateAsync($"{nameof(HomePage)}");
                await _userDialogs.AlertAsync("Could not process request");
            }

        }

        public static void SendEmail(string email, string name)
        {

            var client = new SendGridClient(App.SendGridApiKey);
            var from = new EmailAddress("marjoe.aguilar18@gmail.com", "FEBC PH Stream");
            var subject = "Password Reset Complete";
            var to = new EmailAddress(email);
            var plainTextContent = "Reset Password link";
            var htmlContent =
              $"<strong> " +
                    $" Hi {name}," +
                    $" <br><br><br> " +
                    $"This is to confirm that your FEBC PH Stream account password has been reset. You can now access your account using your new password." +
                    $"<br><br><br> " +
                    $"If you did not initiate this request, please contact our support team immediately at febcph.tech@gmail.com." +
                    $"<br><br><br> " +
                    $"Thank you for using FEBC PH Stream." +
                    $"</strong>";
            var message = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response1 = client.SendEmailAsync(message);
        }

        public async Task<UserData> getApiData(string email)
        {
            var httpClient = new HttpClient();
            var json = await httpClient.GetStringAsync($"{ApiConstants.BaseUrl}user/get-one/" + email);
            UserData userdetails = JsonConvert.DeserializeObject<UserData>(json);

            return userdetails;

        }

        private async Task<string> Reset(ResetPassDto resetPassDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(resetPassDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}user/update-password/{Settings2.UserId}", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;

        }


        private RegistrationResponse ParseUpdateData(string response)
        {
            //_userDialogs.Alert(response, "OK");
            return JsonConvert.DeserializeObject<RegistrationResponse>(response);
        }
    }
}

