﻿using Acr.UserDialogs;
using FEBCApp.Helpers;
using FEBCApp.Models;
using FEBCApp.Services.Base;
using FEBCApp.Settings.Base;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using ImTools;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Prism.Commands;
using Prism.Navigation;
using Prism.Navigation.Xaml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.Tracing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;


namespace FEBCApp.ViewModels
{
    public class DonationPageViewModel : BaseNavigationViewModel
    {

        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;



        public DonationPageViewModel(INavigationService navigationService, IUserDialogs userDialogs, IAppSettings appSettings) : base(navigationService)
        {

            _userDialogs = userDialogs;
            _appSettings = appSettings;


            BackCommand = new DelegateCommand(Back);
            DonationCommand = new DelegateCommand(Donation);


        }


        #region Bindable Commands
        public ICommand BackCommand { get; private set; }
        public ICommand DonationCommand { get; private set; }
        #endregion

        private string _amount;
        private string _errorMessage;
        private string _errorColor;
        private bool _disableButton;

        public string Amount
        {
            get => _amount;
            set
            {
                if (!string.IsNullOrEmpty(value) && decimal.TryParse(value, out decimal amountValue))
                {
                    if (amountValue <= 99)
                    {
                        ErrorMessage = "Min. amount: Php 100.00.";
                        ErrorColor = "Red";
                        DisableButton = false;
                        return; // Exit the property setter if there is an error
                    }
                    else
                    {
                        ErrorMessage = string.Empty;
                        ErrorColor = "Black";
                        DisableButton = true;
                    }
                }

                SetProperty(ref _amount, value);
            }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public string ErrorColor
        {
            get => _errorColor;
            set => SetProperty(ref _errorColor, value);
        }


        public bool DisableButton
        {
            get => _disableButton;
            set => SetProperty(ref _disableButton, value);
        }

        private string _category = "All Categories";
        public string Category
        {
            get => _category;
            set => SetProperty(ref _category, value);
        }

        #region Methods
        public void Back()
        {
            //NavigationService.NavigateAsync(nameof(HomePage));
            //NavigationService.NavigateAsync(nameof(DonationPage2));
            NavigationService.GoBackAsync();
        }
        #endregion


        #region Methods
        public void Donation()
        {

            if (string.IsNullOrEmpty(Amount))
            {
                _userDialogs.Alert("Donation amount is required!");
                return;
            }



            if (Amount == "0")
            {
                _userDialogs.Alert("Donation amount must be greater than zero!");
                return;
            }

            if (!int.TryParse(Amount, out int result))
            {
                _userDialogs.Alert("Donation amount must be numeric!");
                return;
            }




            //_userDialogs.Alert(Category);
            Settings1.DonationCategory = Category;
            Settings1.DonationAmount = Amount;
            var loading = _userDialogs.Loading("Please wait...");
            loading.Hide();
            NavigationService.NavigateAsync(nameof(DonationPage2));




            //await Launcher.OpenAsync(new Uri("https://febc.ph/donate-now/"));
            //await Browser.OpenAsync("https://febc.ph/donate-now/", BrowserLaunchMode.SystemPreferred);
        }
        #endregion
    }


}



