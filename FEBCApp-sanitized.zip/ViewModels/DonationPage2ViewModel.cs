﻿using System;
using System.Windows.Input;
using Acr.UserDialogs;
using FEBCApp.ViewModels.Base;
using FEBCApp.Views;
using Prism.Commands;
using Prism.Navigation;
using Xamarin.Forms;
using FEBCApp.Services.Base;
using FEBCApp.Helpers;
using ImTools;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using FEBCApp.Settings.Base;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net.Http;
using FEBCApp.Constants;
using FEBCApp.Models;
using Xamarin.Essentials;

namespace FEBCApp.ViewModels
{
    public class DonationPage2ViewModel : BaseNavigationViewModel
    {

        private readonly IUserDialogs _userDialogs;
        private readonly IAppSettings _appSettings;

        public DonationPage2ViewModel(INavigationService navigationService, IUserDialogs userDialogs, Settings.Base.IAppSettings appSettings) : base(navigationService)
        {
            _userDialogs = userDialogs;
            _appSettings = appSettings;


            BackCommand = new DelegateCommand(Back);
            DonationCommand = new DelegateCommand(Donation);
            TermsCommand = new DelegateCommand(Terms);
            PrivacyCommand = new DelegateCommand(Privacy);

        }

      

        #region Bindable Commands
        public ICommand BackCommand { get; private set; }
        public ICommand DonationCommand { get; private set; }
        public ICommand TermsCommand { get; private set; }
        public ICommand PrivacyCommand { get; private set; }
        #endregion

        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set => SetProperty(ref _lastName, value);
        }

        private string _selectedCountry;
        public string SelectedCountry
        {
            get => _selectedCountry;
            set => SetProperty(ref _selectedCountry, value);
        }

        private string _selectedStated;
        public string SelectedStated
        {
            get => _selectedStated;
            set => SetProperty(ref _selectedStated, value);
        }

        private string _selectedCity;
        public string SelectedCity
        {
            get => _selectedCity;
            set => SetProperty(ref _selectedCity, value);
        }

        private string _email;
        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value);
        }

        private string _houseNo;
        public string HouseNo
        {
            get => _houseNo;
            set => SetProperty(ref _houseNo, value);
        }

        private string _appartment;
        public string Appartment
        {
            get => _appartment;
            set => SetProperty(ref _appartment, value);
        }

        private string _zipcode;
        public string Zipcode
        {
            get => _zipcode;
            set => SetProperty(ref _zipcode, value);
        }

        private string _donorNote;
        public string DonorNote
        {
            get => _donorNote;
            set => SetProperty(ref _donorNote, value);
        }

        private bool _check;
        public bool IsChecked
        {
            get => _check;
            set => SetProperty(ref _check, value);
        }

        #region Methods
        public void Back()
        {
            //NavigationService.NavigateAsync(nameof(HandshakePage));
            //NavigationService.NavigateAsync(nameof(DonationPage));
            NavigationService.GoBackAsync();
        }

        private async void Terms()
        {
            await Launcher.OpenAsync(new Uri("https://www.febc.org/privacy-policy-2/"));
        }


        private void Privacy()
        {
            _userDialogs.Alert(
                $"By downloading, browsing, accessing or using the FEBC Stream Application (“Mobile Application”), you agree to be bound by these Terms and Conditions of Use. We reserve the right to amend these terms and conditions at any time. If you disagree with any of these Terms and Conditions of Use, you must immediately discontinue your access to the Mobile Application and your use of the Services offered on the Mobile Application. Continued use of the Mobile Application will constitute acceptance of these Terms and Conditions of Use, as may be amended from time to time." +
                $"" +
                $"GENERAL ISSUES ABOUT THE MOBILE APPLICATION AND THE SERVICES" +
                $"" +
                $"Applicability of Terms and Conditions: The use of any Services and/or Mobile Application and the making of any redemptions are subject to these Terms and Conditions of Use." +
                $"" +
                $"Location: The Mobile Application, Services and any redemptions are intended solely for use by users who access the mobile application in the Philippines." +
                $"" +
                $"Scope: The Mobile Application, Services and any redemptions are for your non-commercial, personal use only and must not be used for business purposes." +
                $"" +
                $"Prevention from Use of Mobile Application: We reserve the right to prevent you from using the Mobile Application and service (or any part of them) and to prevent you from making any redemptions." +
                $"" +
                $"Equipment and Networks: The provision of the Services and Mobile Application does not include the provision of a mobile telephone or handheld device or other necessary equipment to access the mobile application or Services or make any redemptions." +
                $"" +
                $"To use the Mobile Application or Services or to make redemptions, you will require Internet connectivity and appropriate telecommunication links. You acknowledge that the terms of agreement with your respective mobile network provider (“Mobile Provider”) will continue to apply when using the Mobile Application. As a result, you may be charged by the Mobile Provider for access to network connection Services for the duration of the connection while accessing the Mobile Application or any such third party charges as may arise. You accept responsibility for any such charges that arise." +
                $"" +
                $"Permission to Use Mobile Application: If you are not the bill payer for the mobile telephone or handheld device being used to access the Mobile Application, you will be assumed to have received permission from the bill payer for using the Mobile Application." +
                $"" +
                $"YOUR OBLIGATION" +
                $"" +
                $"Merchant Terms: You agree to (and shall) abide by the terms and conditions of this service." +
                $"" +
                $"Accurate Information: You warrant that all information provided on registration and contained as part of your account is true, complete and accurate and that you will promptly inform us of any changes to such information by updating the information in your account." +
                $"" +
                $"Prohibitions in Relation to Usage of Services or Mobile Application: Without limitation, you undertake not to use or permit anyone else to use the Services or Mobile Application, such as:" +
                $"" +
                $"1. Sending and/or receiving any material which is not civil or tasteful;" +
                $"" +
                $"Sending and/or receiving any material which is threatening, grossly offensive, of an indecent, obscene or menacing character, blasphemous or defamatory of any person, in contempt of court or in breach of confidence, copyright, rights of personality, publicity or privacy or any other third party rights;" +
                $"" +
                $"Sending and/or receiving any material which is technically harmful (including computer viruses, logic bombs, Trojan horses, worms, harmful components, corrupted data or other malicious software or harmful data);" +
                $"" +
                $"Causing annoyance, inconvenience or needless anxiety;" +
                $"" +
                $"Intercepting or attempting to intercept any communication transmitted by way of a telecommunications system;" +
                $"" +
                $"Any purpose other than which we have designed them or intended them to be used;" +
                $"" +
                $"Any fraudulent purpose;" +
                $"" +
                $"Any other than in conformity with accepted Internet practices and practices of any connected networks;" +
                $"" +
                $"Any way which is calculated to incite hatred against any ethnic, religious or any other minority or is otherwise calculated to adversely affect any individual, group or entity; or" +
                $"1. Committing any act that would or does impose an unreasonable or disproportionately large load on our infrastructure." +
                $"" +
                $"Prohibitions in Relation to Usage of Services, Mobile Application: Without limitation, you further undertake not to or permit anyone else to:" +
                $"" +
                $"1. Attempt to circumvent our security or network including to access data not intended for you, log in to a server or account you are not expressly authorized to access or probe the security of other networks (such as running a port scan);" +
                $"" +
                $"Execute any form of network monitoring which will intercept data not intended for you;" +
                $"" +
                $"Extract data from or hack into the Mobile Application;" +
                $"" +
                $"Use the Services or Mobile Application in breach of these Terms and Conditions of Use;" +
                $"" +
                $"Engage in any unlawful activity in connection with the use of the Mobile Application or the Services; or" +
                $"" +
                $"Engage in any conduct which, in our exclusive reasonable opinion, restricts or inhibits any other customer from properly using or enjoying the Mobile Application or Services." +
                $"" +
                $"RULES ABOUT USE OF THE SERVICE AND THE MOBILE APPLICATION" +
                $"" +
                $"1. We will use reasonable endeavors to correct any errors or omissions as soon as practicable after being notified of them. However, we do not guarantee that the Services or the Mobile Application will be free of faults nor do we accept liability for any such faults, errors or omissions." +
                $"" +
                $"We do not warrant that your use of the Services or the Mobile Application will be uninterrupted and we do not warrant that any information (or messages) transmitted via the Services or the Mobile Application will be transmitted accurately, reliably in a timely manner or at all. Notwithstanding that, we will try to allow uninterrupted access to the Services and the Mobile Application, access to the Services and the Mobile Application may be suspended, restricted or terminated at any time." +
                $"" +
                $"We do not give any warranty that the Services and the Mobile Application are free from viruses or anything else which may have a harmful effect on any technology." +
                $"" +
                $"We reserve the right to change, modify, substitute, suspend or remove without notice any information or Services on the Mobile Application from time to time. Your access to the Mobile Application and/or the Services may also be occasionally restricted to allow for repairs, maintenance or the introduction of new facilities or Services. We will attempt to restore such access as soon as we reasonably can. For the avoidance of doubt, we reserve the right to withdraw any information or Services from the Mobile Application at any time." +
                $"" +
                $"We reserve the right to block access to and/or to edit or remove any material which in our reasonable opinion may give rise to a breach of these Terms and Conditions of Use." +
                $"" +
                $"SUSPENSION AND TERMINATION" +
                $"" +
                $"1. If you use (or anyone other than you, with your permission uses) the Mobile Application, any Services in contravention of these Terms and Conditions of Use, we may suspend your use of the Services and/or Mobile Application." +
                $"" +
                $"If we suspend the Services or Mobile Application, we may refuse to restore the Services or Mobile Application for your use until we receive an assurance from you, in a form we deem acceptable, that there will be no further breach of the provisions of these Terms and Conditions of Use." +
                $"" +
                $"Without limitation to anything else in this Clause 8, we shall be entitled immediately or at any time (in whole or in part) to: (a) suspend the Services and/or Mobile Application; (b) suspend your use of the Services and/or Mobile Application; and/or (c) suspend the use of the Services and/or Mobile Application for persons we believe to be connected (in whatever manner) to you, if:" +
                $"" +
                $"You commit any breach of these Terms and Conditions of Use;" +
                $"" +
                $"We suspect, on reasonable grounds, that you have, might or will commit a breach of these Terms and Conditions of Use; or" +
                $"" +
                $"We suspect, on reasonable grounds, that you may have committed or be committing any fraud against us or any person." +
                $"" +
                $"Our rights under this Clause 8 shall not prejudice any other right or remedy we may have in respect of any breach or any rights, obligations or liabilities accrued prior to termination." +
                $"" +
                $"DISCLAIMER AND EXCLUSION OF LIABILITY" +
                $"" +
                $"1. The Mobile Application, the Services, the information on the Mobile Application and use of all related facilities are provided on an “as is, as available” basis without any warranties whether express or implied." +
                $"" +
                $"To the fullest extent permitted by applicable law, we disclaim all representations and warranties relating to the Mobile Application and its contents, including in relation to any inaccuracies or omissions in the Mobile Application, warranties of merchantability, quality, fitness for a particular purpose, accuracy, availability, non-infringement or implied warranties from course of dealing or usage of trade." +
                $"" +
                $"We do not warrant that the Mobile Application will always be accessible, uninterrupted, timely, secure, error free or free from computer virus or other invasive or damaging code or that the Mobile Application will not be affected by any acts of God or other force majeure events, including inability to obtain or shortage of necessary materials, equipment facilities, power or telecommunications, lack of telecommunications equipment or facilities and failure of information technology or telecommunications equipment or facilities." +
                $"" +
                $"While we may use reasonable efforts to include accurate and up-to-date information on the Mobile Application, we make no warranties or representations as to its accuracy, timeliness or completeness." +
                $"" +
                $"We shall not be liable for any acts or omissions of any third parties howsoever caused and for any direct, indirect, incidental, special, consequential or punitive damages, howsoever caused, resulting from or in connection with the mobile application and the Services offered in the mobile application, your access to, use of or inability to use the mobile application or the Services offered in the mobile application, reliance on or downloading from the mobile application and/or Services, or any delays, inaccuracies in the information or in its transmission including but not limited to damages for loss of business or profits, use, data or other intangible, even if we have been advised of the possibility of such damages." +
                $"" +
                $"We shall not be liable in contract, tort (including negligence or breach of statutory duty) or otherwise howsoever and whatever the cause thereof, for any indirect, consequential, collateral, special or incidental loss or damage suffered or incurred by you in connection with the Mobile Application and these Terms and Conditions of Use. For the purposes of these Terms and Conditions of Use, indirect or consequential loss or damage includes, without limitation, loss of revenue, profits, anticipated savings or business, loss of data or goodwill, loss of use or value of any equipment including software, claims of third parties, and all associated and incidental costs and expenses." +
                $"" +
                $"The above exclusions and limitations apply only to the extent permitted by law. None of your statutory rights as a consumer that cannot be excluded or limited are affected." +
                $"" +
                $"Notwithstanding our efforts to ensure that our system is secure, you acknowledge that all electronic data transfers are potentially susceptible to interception by others. We cannot, and do not, warrant that data transfers pursuant to the Mobile Application, or electronic mail transmitted to and from us, will not be monitored or read by others." +
                $"" +
                $"INDEMNITY" +
                $"" +
                $"You agree to indemnify and keep us indemnified against any claim, action, suit or proceeding brought or threatened to be brought against us which is caused by or arising out of (a) your use of the Services, (b) any other party’s use of the Services using your user ID, verification PIN and/or any identifier number, and/or (c) your breach of any of these Terms and Conditions of Use, and to pay us damages, costs and interest in connection with such claim, action, suit or proceeding." +
                $"" +
                $"INTELLECTUAL PROPERTY RIGHTS" +
                $"" +
                $"1. All editorial content, information, photographs, illustrations, artwork and other graphic materials, and names, logos and trademarks on the Mobile Application are protected by copyright laws and/or other laws and/or international treaties and belong to us and/or our suppliers, as the case may be. These works, logos, graphics, sounds or images may not be copied, reproduced, retransmitted, distributed, disseminated, sold, published, broadcasted or circulated whether in whole or in part, unless expressly permitted by us and/or our suppliers, as the case may be." +
                $"" +
                $"Nothing contained on the Mobile Application should be construed as granting by implication, estoppel, or otherwise, any license or right to use any trademark displayed on the Mobile Application without our written permission. Misuse of any trademarks or any other content displayed on the Mobile Application is prohibited." +
                $"" +
                $"We will not hesitate to take legal action against any unauthorized usage of our trademarks, name or symbols to preserve and protect its rights in the matter. All rights not expressly granted herein are reserved. Other product and company names mentioned herein may also be the trademarks of their respective owners." +
                $"" +
                $"AMENDMENTS" +
                $"" +
                $"We may periodically make changes to the contents of the Mobile Application, including the descriptions and prices of goods and Services advertised at any time and without notice. We assume no liability or responsibility for any errors or omissions in the content of the Mobile Application." +
                $"" +
                $"We reserve the right to amend these Terms and Conditions of Use from time to time without notice. The revised Terms and Conditions of Use will be posted on the Mobile Application and shall take effect from the date of such posting. You are advised to review these terms and conditions periodically as they are binding upon you." +
                $"" +
                $"APPLICABLE LAW AND JURISDICTION" +
                $"" +
                $"1. By accessing the Mobile Application, both you and we agree that the laws of the Philippines, without regard to the conflicts of laws principles thereof, will apply to all matters relating to the use of the Mobile Application." +
                $"" +
                $"You accept and agree that both you and we shall submit to the exclusive jurisdiction of the courts of the Philippines in respect of any dispute arising out of and/or in connection with these Terms and Conditions of Use.",
                "TERMS AND CONDITIONS OF USE", "OK");
        }


        private async void Donation()
        {


            if (string.IsNullOrEmpty(FirstName))
            {
                _userDialogs.Alert("First Name is required!");
                return;
            }



            if (string.IsNullOrEmpty(LastName))
            {
                _userDialogs.Alert("Last Name is required!");
                return;
            }


            if (string.IsNullOrEmpty(SelectedCountry))
            {
                _userDialogs.Alert("Country is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedStated))
            {
                _userDialogs.Alert("State / Province is required!");
                return;
            }

            if (string.IsNullOrEmpty(SelectedCity))
            {
                _userDialogs.Alert("City / Town is required!");
                return;
            }

            if (string.IsNullOrEmpty(Zipcode))
            {
                _userDialogs.Alert("Postal / Zipcode is required!");
                return;
            }

            if (string.IsNullOrEmpty(Email))
            {
                _userDialogs.Alert("Email is required!");
                return;
            }

            if (!IsChecked)
            {
                _userDialogs.Alert("You must agree with terms and condition!");
                return;
            }


            //_userDialogs.Alert(Settings1.UserId);
            var loading = _userDialogs.Loading("Please wait...");

            try
            {
                UserInfoDto userInfoDto = new UserInfoDto
                {
                    Email = Email,
                    Firstname = FirstName,
                    Lastname = LastName,
                    Country = SelectedCountry,
                    SelectedCity = SelectedCity,
                    SelectedStated = SelectedStated,
                    Zipcode = Zipcode,
                    HouseNo = HouseNo,
                    DonorNote = DonorNote,
                    Category = Settings1.DonationCategory,
                    Station = "test",
                    Amount = Settings1.DonationAmount,
                    State = "test",
                    Gateway = "Union Bank"
                };


                string result = await UserInfo(userInfoDto);
                //_userDialogs.Alert(result);
                UserData response = ParseResponse(result);
                //_userDialogs.Alert(result);


                loading.Hide();
                Settings1.UserEmail = Email;
                //await NavigationService.NavigateAsync(nameof(HomePage));

                DonationInfo.Firstname = FirstName;
                DonationInfo.Lastname = LastName;
                DonationInfo.City = SelectedCity;
                DonationInfo.Country = SelectedCountry;
                DonationInfo.Email = Email;
                DonationInfo.Zipcode = Zipcode;
                DonationInfo.State = SelectedStated;
                DonationInfo.Address1 = HouseNo;

                await NavigationService.NavigateAsync(nameof(HandshakePage));
             
            }
            catch (Exception)
            {
                loading.Hide();
                _userDialogs.Alert("Could not process request");
                //await NavigationService.NavigateAsync(nameof(HandshakePage));
            }

        }

        private async Task<string> UserInfo(UserInfoDto userInfoDto)
        {
            HttpClient httpClient = new HttpClient();
            string serializedObject = JsonConvert.SerializeObject(userInfoDto);
            HttpContent httpContent = new StringContent(serializedObject);

            httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            HttpResponseMessage result = await httpClient.PostAsync($"{ApiConstants.BaseUrl}donation/add-record", httpContent);
            string response = await result.Content.ReadAsStringAsync();

            return response;
        }


        private UserData ParseResponse(string response)
        {
            return JsonConvert.DeserializeObject<UserData>(response);
        }
        #endregion



    }
}



