﻿using DryIoc;
using FEBCApp.Settings.Base;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Schema;
using Plugin.Settings.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FEBCApp.Settings
{
    public class AppSettings : IAppSettings
    {
        private readonly ISettings _settings;

        public AppSettings(ISettings settings)
        {
            _settings = settings;
        }

        public bool IsAuthenticated 
        { 
            get => _settings.GetValueOrDefault(nameof(IsAuthenticated), false); 
            set => _settings.AddOrUpdateValue(nameof(IsAuthenticated), value); 
        }

        public string Username
        {
            get => _settings.GetValueOrDefault(nameof(Username), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(Username), value); 
        }

        public string FirstName
        {
            get => _settings.GetValueOrDefault(nameof(FirstName), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(FirstName), value);
        }

        public string LastName
        {
            get => _settings.GetValueOrDefault(nameof(LastName), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(LastName), value);
        }

        public string Gender
        {
            get => _settings.GetValueOrDefault(nameof(Gender), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(Gender), value);
        }

        public string AgeRange
        {
            get => _settings.GetValueOrDefault(nameof(AgeRange), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(AgeRange), value);
        }

        public string Country
        {
            get => _settings.GetValueOrDefault(nameof(Country), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(Country), value);
        }

        public string City
        {
            get => _settings.GetValueOrDefault(nameof(City), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(City), value);
        }

        public string Usertype { 
            get => _settings.GetValueOrDefault(nameof(Usertype), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(Usertype), value);
        }
        public string Id
        {
            get => _settings.GetValueOrDefault(nameof(Id), string.Empty);
            set => _settings.AddOrUpdateValue(nameof(Id), value);
        }
        //public string Avatar { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public string Avatar
        {
        get => _settings.GetValueOrDefault(nameof(Avatar), string.Empty);
        set => _settings.AddOrUpdateValue(nameof(Avatar), value);
        }

        public void FlushSession()
        {
            IsAuthenticated = false;
            FirstName = string.Empty;
            LastName = string.Empty;
            Gender = string.Empty;
            AgeRange = string.Empty;
            Country = string.Empty;
            City = string.Empty;
            Usertype = string.Empty;
            Id = string.Empty;
            Avatar = string.Empty;
        }
    }
}
