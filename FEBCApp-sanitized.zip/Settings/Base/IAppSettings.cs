﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Settings.Base
{
    public interface IAppSettings
    {
        bool IsAuthenticated { get; set; }
        string Username { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string Gender { get; set; }
        string AgeRange { get; set; }
        string Country { get; set; }
        string City { get; set; }
        string Id { get; set; }
        string Usertype { get; set; }

        string Avatar { get; set; }
        void FlushSession();
    }
}
