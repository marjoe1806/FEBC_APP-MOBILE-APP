﻿namespace spectrumChart
{
    internal class Chart
    {
    }
}