﻿using Acr.UserDialogs;
using DryIoc;
using FEBCApp.Constants;
using FEBCApp.Settings;
using FEBCApp.Settings.Base;
using FEBCApp.Views;
using Plugin.Media;
using Plugin.Settings;
using Prism;
using Prism.DryIoc;
using Prism.Ioc;
using Prism.Navigation;
using Syncfusion.Licensing;
using System;
using FEBCApp.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp
{
    public partial class App : PrismApplication
    {
        public App() : this(null) { }

        public App(IPlatformInitializer platformInitializer) : base(platformInitializer) { }

        public T Resolve<T>() => Container.Resolve<T>();
        public INavigationService NavigationSvc => NavigationService;

        public static string SendGridApiKey = string.Empty; // Configure securely outside the mobile client.
        protected override void OnInitialized()
        {
            SyncfusionLicenseProvider.RegisterLicense(AppConstants.SyncfusionLicenseKey);

            InitializeComponent();
            Device.SetFlags(new[]
            {
                "CarouselView_Experemental",
                "IndicatorView_Experemental"
            });
            XF.Material.Forms.Material.Init(this);

            var settings = Resolve<IAppSettings>();

            //settings.FlushSession();

            if (settings.IsAuthenticated)
                NavigationService.NavigateAsync($"app:///{nameof(HomePage)}");
            else
                NavigationService.NavigateAsync($"app:///{nameof(LoginPage)}");


            //NavigationService.NavigateAsync($"app:///{nameof(ProfilePage)}");

           
        }


        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterInstance(UserDialogs.Instance);
            containerRegistry.RegisterInstance(CrossSettings.Current);
            containerRegistry.RegisterInstance(CrossMedia.Current);

            containerRegistry.Register<IAppSettings, AppSettings>();

            containerRegistry.RegisterForNavigation<LoginPage>();
            containerRegistry.RegisterForNavigation<HomePage>();
            containerRegistry.RegisterForNavigation<ProfilePage>();
            containerRegistry.RegisterForNavigation<SignupPage>();
            containerRegistry.RegisterForNavigation<AboutPage>();
            containerRegistry.RegisterForNavigation<HandshakePage>();
            containerRegistry.RegisterForNavigation<DonationPage>();
            containerRegistry.RegisterForNavigation<DonationPage2>();
            containerRegistry.RegisterForNavigation<ForgotPasswordPage>();
            containerRegistry.RegisterForNavigation<ResetPasswordPage>();
            containerRegistry.RegisterForNavigation<UnionPage>();
            containerRegistry.RegisterForNavigation<VerificationPage>();
        }
    }
}
