﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Constants
{
    public static class AppConstants
    {
        public const string SyncfusionLicenseKey = ""; // Configure securely for local builds.
    }
}
