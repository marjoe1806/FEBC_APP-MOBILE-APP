﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace FEBCApp.Constants
{
    public static class ApiConstants
    {
        //public const string BaseUrl = "https://landbank-jk.herokuapp.com/";
        public const string BaseUrl = "http://119.12.166.178:2727/api/v1/";
        //internal static SerializationInfo BaseApiUrl;
    }
}
