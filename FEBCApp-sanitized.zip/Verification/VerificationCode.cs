﻿using System;
using System.Collections.Generic;
using System.Text;
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace FEBCApp.Verification
{
    class VerificationCode
    {
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        #region Setting Constants

        private const string LastEmailSettings = "code_key";
        private const string LastIdSettingsKey = "last_id_key";
        private static readonly string SettingsDefault = string.Empty;

        #endregion


        public static string Code
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastEmailSettings, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastEmailSettings, value);
            }
        }
        public static string DonationAmount
        {
            get
            {
                return AppSettings.GetValueOrDefault(LastIdSettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(LastIdSettingsKey, value);
            }
        }
    }
}
