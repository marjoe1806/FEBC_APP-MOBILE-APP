# FEBCApp

Legacy Xamarin.Forms mobile application for FEBC radio streaming, account management, and donation-related workflows.

## Technology

- C# / .NET Standard 2.0
- Xamarin.Forms
- Prism
- REST API integrations

## Security notice

A hard-coded UnionBank client secret was removed from this repository. The exposed credential must be revoked and rotated before this application is used again.

Payment-provider client secrets must not be stored in a mobile application. Move payment authorization and signing to a trusted backend API, and let the mobile application call that backend using authenticated, short-lived tokens.

## Local setup

1. Restore NuGet packages.
2. Configure non-secret API endpoints for the target environment.
3. Replace direct payment-provider calls with a secure backend integration.
4. Build using a Xamarin-compatible Visual Studio environment.

## Repository hygiene

Generated `bin` and `obj` directories, IDE files, secrets, certificates, and local configuration are excluded from source control.
