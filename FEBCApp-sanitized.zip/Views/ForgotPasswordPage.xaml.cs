﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using FEBCApp.Constants;
using SendGrid;
using SendGrid.Helpers.Mail;


namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ForgotPasswordPage : ContentPage
    {
 
        public ForgotPasswordPage()
        {
            InitializeComponent();

            Email.Keyboard = Keyboard.Email;

        }

    }

}
