﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();

            P0.Text = "FEBC PH Stream is the official radio | audio streaming app of FEBC Philippines. " +
                "You can now listen to any of the FEBC Radio Stations and FEBC Streaming Audio Channels " +
                "using your mobile phone, with an “easy to use” interface.";
            P1.Text = "With FEBC PH Stream, you can listen to the broadcast of 702 DZAS, 98.7 DZFE FM," +
                "NOW XD (Christian Contemporary), Pinoy Connection (OFW Broadcast) and others.";
            P2.Text = "FEATURES:";
            P3.Text = "Connect with other FEBC PH listeners through LIVE CHAT feature.";
            P4.Text = "Keep up to date with the social media page of FEBC Stations, Streaming audio, and " +
                "the official FEBC Website";
            P5.Text = "Donate to the Gospel Broadcast Mission of FEBC Philippines.";
            P6.Text = "v1.0";
        }
    }
}