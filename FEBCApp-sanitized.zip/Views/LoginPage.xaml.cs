﻿using FEBCApp.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {

        private IStreamService streamService;

        public LoginPage()
        {
            InitializeComponent();
            Email.Keyboard = Keyboard.Email;

            streamService = DependencyService.Get<IStreamService>();
        }

        protected override void OnDisappearing()
        {
            // Stop the audio stream when the user navigates away from the login page
            streamService.Stop();
            base.OnDisappearing();
        }
    }
}