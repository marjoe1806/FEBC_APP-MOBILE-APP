﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using FEBCApp.Verification;
using Acr.UserDialogs;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VerificationPage : ContentPage
    {

        private Timer _timer;
        private int _timeLeft = 60; // The amount of time (in seconds) the user has to complete the verification process
        private int _resendCooldownTimeLeft; // The amount of time (in seconds) left until the user can request a new verification code
        private const int ResendCooldownTime = 60;

        public  VerificationPage()
        {
            InitializeComponent();

            _timer = new Timer(1000);
            _timer.Elapsed += OnTimerElapsed;

            if (VerificationCode.Code != "000000") {
                _timeLeft = 60;
                _timer.Start();
            }

        }


        protected override bool OnBackButtonPressed()
        {

            // Disable the back butto
            base.OnBackButtonPressed();
            return true;
        }


        private void Resendbutton(object sender, EventArgs e)
        {
          
            StartTimer();
         

        }
        private void StartTimer()
        {
            _resendCooldownTimeLeft = ResendCooldownTime;
            _timer.Start();
        }

        private void StopTimer()
        {
            _timer.Stop();
            Resend.Text = "Resend Code";
            Resend.IsEnabled = true;

        }

        private void VerifyButton(object sender, EventArgs e)
        {

            if (VerifyCode.Text == "") {
                Verify.IsEnabled = false;
            }
           
                StopTimer();
        }

        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            _timeLeft--;

            // Update the UI with the remaining time
            Device.BeginInvokeOnMainThread( async() =>
            {
                Resend.Text = $"( {_timeLeft} )";
                Resend.IsEnabled = false;

                if (_timeLeft == 0)
                {
                    StopTimer();
                    Resend.Text = "Resend Code";
                    VerifyCode.Text = "";
                    Resend.IsEnabled = true;
                    _timeLeft = 60;
                   
                    // Handle the expiration of the verification code here
                    // For example, you could display a message to the user or prompt them to request a new code
                    VerificationCode.Code = "000000";
                    await DisplayAlert("Verification Timeout", "The verification code has expired. Please request a new code.", "OK");
                }
                if (_resendCooldownTimeLeft > 0)
                {
                    _resendCooldownTimeLeft--;

                    // Update the UI with the remaining resend cooldown time
                    Device.BeginInvokeOnMainThread(  () =>
                    {
                        Resend.IsEnabled = false;
                        Resend.Text = $"( {_resendCooldownTimeLeft} )";
                    });

                    if (_resendCooldownTimeLeft == 0)
                    {
                        StopTimer();

                        // The user can now request a new verification code
                        Device.BeginInvokeOnMainThread( () =>
                        {
                            Resend.IsEnabled = true;
                            Resend.Text = "Resend code";
                            VerificationCode.Code = "000000";
                        });
                    }
                }
            });
        }

      
    }
}