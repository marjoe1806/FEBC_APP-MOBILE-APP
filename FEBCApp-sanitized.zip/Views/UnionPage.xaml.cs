﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FEBCApp.Helpers;
using Xamarin.Forms;
using FEBCApp.Services.Cybersource;

namespace FEBCApp.Views
{
    public partial class UnionPage : ContentPage
    {

        private DonationService donationService;

        public UnionPage()
        {
            InitializeComponent();
            AmountEntry.Text = Settings1.DonationAmount;
            donationService = new DonationService();
        }

        private void DonateButton_Clicked(object sender, EventArgs e)
        {
            decimal donationAmount = decimal.Parse(AmountEntry.Text);
            string currency = "PH";

            string cybersourceRedirectUrl = donationService.GetCybersourceRedirectUrl(donationAmount, currency);

            // Redirect the user to the CyberSource payment page
            //Device.OpenUri(new System.Uri(cybersourceRedirectUrl));
        }
    }
}
