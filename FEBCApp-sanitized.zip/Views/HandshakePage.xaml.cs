﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HandshakePage : ContentPage
    {
        public HandshakePage()
        {
            InitializeComponent();

        }



    }
}
