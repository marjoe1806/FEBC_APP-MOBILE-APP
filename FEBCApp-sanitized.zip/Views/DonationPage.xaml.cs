﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]

    public partial class DonationPage : ContentPage
    {

        public ObservableCollection<string> Options { get; set; }

        public DonationPage()
        {

            InitializeComponent();
            donation_amount.Text = "100";

        }

        private void Button_Clicked1(object sender, EventArgs e)
        {
            donation_amount.Text = "100";
        }

        private void Button_Clicked2(object sender, EventArgs e)
        {
            donation_amount.Text = "500";
        }

        private void Button_Clicked3(object sender, EventArgs e)
        {
            donation_amount.Text = "1000";
        }

        private void Button_Clicked4(object sender, EventArgs e)
        {
            donation_amount.Text = "5000";
        }

        private void Button_Clicked5(object sender, EventArgs e)
        {
            donation_amount.Text = "10000";
        }

        private void Button_Clicked6(object sender, EventArgs e)
        {
            donation_amount.Text = "20000";
        }

        private async void DButton(object sender, EventArgs e)
        {

            string[] options = new string[] { "All categories", "Gospel Broadcast Donation" };

            var action = await DisplayActionSheet("Chose one!", "", "Cancel", options);

            if (action == "All categories")
            {
                //BCategory.Text = "All Categories";
                //Category.Text = "All Categories";
            }
            else {
                //BCategory.Text = "Gospel Broadcast Donation";
                //Category.Text = "Gospel Broadcast Donation";
            }
        }

        private void Picker_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedOption = (sender as Picker).SelectedItem as string;
            // Perform actions based on the selectedOption
            // ...
        }

    }
}
