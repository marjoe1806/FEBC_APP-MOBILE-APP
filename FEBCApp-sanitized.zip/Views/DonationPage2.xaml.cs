﻿using System;
using System.Collections.Generic;


using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FEBCApp.Views
{
    public partial class DonationPage2 : ContentPage
    {

        private Dictionary<string, List<string>> countryStates = new Dictionary<string, List<string>>
        {
            { "Philippines", new List<string>
                {
                    "Abra", "Agusan del Norte", "Agusan del Sur", "Aklan", "Albay", "Antique", "Apayao",
                    "Aurora", "Basilan", "Bataan", "Batanes", "Batangas", "Benguet", "Biliran", "Bohol",
                    "Bukidnon", "Bulacan", "Cagayan", "Camarines Norte", "Camarines Sur", "Camiguin", "Capiz",
                    "Catanduanes", "Cavite", "Cebu", "Compostela Valley", "Cotabato", "Davao del Norte",
                    "Davao del Sur", "Davao Occidental", "Davao Oriental", "Dinagat Islands", "Eastern Samar",
                    "Guimaras", "Ifugao", "Ilocos Norte", "Ilocos Sur", "Iloilo", "Isabela", "Kalinga",
                    "La Union", "Laguna", "Lanao del Norte", "Lanao del Sur", "Leyte", "Maguindanao",
                    "Marinduque", "Masbate", "Metro Manila", "Misamis Occidental", "Misamis Oriental",
                    "Mountain Province", "Negros Occidental", "Negros Oriental", "Northern Samar", "Nueva Ecija",
                    "Nueva Vizcaya", "Occidental Mindoro", "Oriental Mindoro", "Palawan", "Pampanga",
                    "Pangasinan", "Quezon", "Quirino", "Rizal", "Romblon", "Samar", "Sarangani", "Siquijor",
                    "Sorsogon", "South Cotabato", "Southern Leyte", "Sultan Kudarat", "Sulu", "Surigao del Norte",
                    "Surigao del Sur", "Tarlac", "Tawi-Tawi", "Zambales", "Zamboanga del Norte",
                    "Zamboanga del Sur", "Zamboanga Sibugay"
                }
            },
            { "United States", new List<string>
        {
            "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware",
            "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky",
            "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi",
            "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico",
            "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania",
            "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
            "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"
        }
            },
            { "Canada", new List<string> { "Ontario", "Quebec", "British Columbia" } },
            { "United Kingdom", new List<string> { "England", "Scotland", "Wales" } },
            { "Australia", new List<string> { "New South Wales", "Victoria", "Queensland" } },
            { "Germany", new List<string> { "Bavaria", "North Rhine-Westphalia", "Baden-Württemberg" } },
            { "France", new List<string> { "Île-de-France", "Provence-Alpes-Côte d'Azur", "Auvergne-Rhône-Alpes" } },
            { "Brazil", new List<string> { "São Paulo", "Rio de Janeiro", "Minas Gerais" } },
           { "China", new List<string>
                {
                    "Anhui", "Fujian", "Gansu", "Guangdong", "Guizhou", "Hainan", "Hebei", "Heilongjiang",
                    "Henan", "Hubei", "Hunan", "Jiangsu", "Jiangxi", "Jilin", "Liaoning", "Qinghai",
                    "Shaanxi", "Shandong", "Shanxi", "Sichuan", "Yunnan", "Zhejiang", "Guangxi",
                    "Inner Mongolia", "Ningxia", "Xinjiang", "Tibet", "Beijing", "Chongqing",
                    "Shanghai", "Tianjin"
                }
            },
            { "India", new List<string> { "Maharashtra", "Karnataka", "Tamil Nadu" } },
            { "Afghanistan", new List<string>
                {
                    "Badakhshan", "Badghis", "Baghlan", "Balkh", "Bamyan", "Daykundi", "Farah", "Faryab",
                    "Ghazni", "Ghor", "Helmand", "Herat", "Jowzjan", "Kabul", "Kandahar", "Kapisa", "Khost",
                    "Kunar", "Kunduz", "Laghman", "Logar", "Nangarhar", "Nimruz", "Nuristan", "Paktika",
                    "Paktia", "Panjshir", "Parwan", "Samangan", "Sar-e Pol", "Takhar", "Uruzgan", "Wardak",
                    "Zabul"
                }
            },
            { "Albania", new List<string>
                {
                    "Berat", "Dibër", "Durrës", "Elbasan", "Fier", "Gjirokastër", "Korçë", "Kukës",
                    "Lezhë", "Shkodër", "Tiranë", "Vlorë"
                }
            },
            { "Algeria", new List<string>
                {
                    "Adrar", "Aïn Defla", "Aïn Témouchent", "Algiers", "Annaba", "Batna", "Béchar", "Béjaïa",
                    "Biskra", "Blida", "Bordj Bou Arréridj", "Bouira", "Boumerdès", "Chlef", "Constantine",
                    "Djelfa", "El Bayadh", "El Oued", "El Tarf", "Ghardaïa", "Guelma", "Illizi", "Jijel",
                    "Khenchela", "Laghouat", "M'Sila", "Mascara", "Médéa", "Mila", "Mostaganem"
                }
            },
             { "South Korea", new List<string>
                {
                    "Seoul", "Busan", "Incheon", "Daegu", "Gwangju", "Daejeon", "Ulsan", "Sejong",
                    "Gyeonggi", "Gangwon", "Chungbuk", "Chungnam", "Jeonbuk", "Jeonnam", "Gyeongbuk",
                    "Gyeongnam", "Jeju"
                }
            },
              { "Japan", new List<string>
                {
                    "Hokkaido", "Aomori", "Iwate", "Miyagi", "Akita", "Yamagata", "Fukushima",
                    "Ibaraki", "Tochigi", "Gunma", "Saitama", "Chiba", "Tokyo", "Kanagawa",
                    "Niigata", "Toyama", "Ishikawa", "Fukui", "Yamanashi", "Nagano", "Gifu",
                    "Shizuoka", "Aichi", "Mie", "Shiga", "Kyoto", "Osaka", "Hyogo", "Nara",
                    "Wakayama", "Tottori", "Shimane", "Okayama", "Hiroshima", "Yamaguchi",
                    "Tokushima", "Kagawa", "Ehime", "Kochi", "Fukuoka", "Saga", "Nagasaki",
                    "Kumamoto", "Oita", "Miyazaki", "Kagoshima", "Okinawa"
                }
            },
              { "Argentina", new List<string>
                {
                    "Buenos Aires", "Córdoba", "Santa Fe", "Mendoza", "Tucumán", "Chubut"
                }
            },// Add more countries and their respective states
               { "Mexico", new List<string> { "Mexico City", "Jalisco", "Veracruz", "Puebla", "Guerrero" } },
               { "Netherlands", new List<string> { "North Holland", "South Holland", "Utrecht", "Gelderland", "North Brabant" } },
               { "Russia", new List<string> { "Moscow", "Saint Petersburg", "Novosibirsk" } },
               { "Spain", new List<string> { "Madrid", "Barcelona", "Valencia" } },
               { "Switzerland", new List<string> { "Zurich", "Geneva", "Bern" } },
               { "United Arab Emirates", new List<string> { "Dubai", "Abu Dhabi", "Sharjah" } },
        };

        public DonationPage2()
        {
            InitializeComponent();
        }
        private void CountryPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = CountryPicker.SelectedItem as string;

            if (selectedCountry != null)
            {
                List<string> states;
                if (countryStates.TryGetValue(selectedCountry, out states))
                {
                    StatePicker.ItemsSource = states;
                    StatePicker.IsEnabled = true;
                }
                else
                {
                    StatePicker.ItemsSource = null;
                    StatePicker.IsEnabled = false;
                }
            }
        }
    }
}
