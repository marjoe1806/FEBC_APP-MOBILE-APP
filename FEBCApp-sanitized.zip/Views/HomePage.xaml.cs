﻿using FEBCApp.Services.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using FEBCApp.Settings;
using FEBCApp.Settings.Base;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.ComponentModel;
using Acr.UserDialogs;
using System.Threading.Tasks;

namespace FEBCApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
       // private readonly IAppSettings _appSettings;
        public HomePage()
        {
            InitializeComponent();

        }


        protected override bool OnBackButtonPressed()
        {
            //_appSettings.FlushSession();

            //DependencyService.Get<IStreamService>().Pause();
            //DependencyService.Get<IStreamService>().Stop();
            // Disable the back butto
            base.OnBackButtonPressed();
            return false;
        }

        protected override void OnDisappearing()
        {
            // Stop the audio stream when the user navigates away from the login page
          
            base.OnDisappearing();
            // Check if the user is empty
            if (string.IsNullOrEmpty(App.Current.Properties["User"] as string))
            {
                // If the user is empty, navigate back to the login page
                Navigation.PushAsync(new LoginPage());
            }

        }
    }
}