﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Services.Cybersource
{
    class CybersourceSaleResponse
    {
        public string Status { get; internal set; }
    }
}
