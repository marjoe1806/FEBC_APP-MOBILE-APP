﻿
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Web;


namespace FEBCApp.Services.Cybersource
{
    public class DonationService
    {
        private const string MerchantId = "006010000017694";
        private const string ProfileId = "5ACE8595-AB61-438C-9574-44A0C33C68AF";
        private const string AccessKey = "e6f3bb1de8c0341bad37d79f84e6cd3d";
        private const string SecretKey = "1b92507b6eb3423e8e0339095657558c45f7c14ad7fb4387b59615ffbd2b6ad47cb6a565bb1b4f769c1a5290b06ba563ab7ff408335d4c30885c4bde242e04ce9558165222d5485cbbdc60d8130c6e21b97f80e2509f4d22b7e1b9735fc4e18555022ce883084f0d846a155a3e3511041f8da6bedeea482a9294b48333e85364";
        private const string CybersourceApiEndpoint = "https://secureacceptance.cybersource.com/pay";
        private const string ResponseUrl = "https://yourwebsite.com/donation-response"; // URL to handle the response from CyberSource

        public string GetCybersourceRedirectUrl(decimal amount, string currency)
        {
            // Generate secure token
            string timestamp = DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString();
            string data = MerchantId + ProfileId + timestamp;
            byte[] hmacSignature = HashHMAC(Encoding.UTF8.GetBytes(SecretKey), Encoding.UTF8.GetBytes(data));
            string secureToken = Convert.ToBase64String(hmacSignature);

            // Construct the form parameters
            var formParams = new Dictionary<string, string>
            {
                { "access_key", HttpUtility.UrlEncode(MerchantId) },
                { "profile_id", HttpUtility.UrlEncode(ProfileId) },
                { "transaction_type", HttpUtility.UrlEncode("sale") },
                { "reference_number", HttpUtility.UrlEncode(Guid.NewGuid().ToString()) },
                { "amount", HttpUtility.UrlEncode(amount.ToString()) },
                { "currency", HttpUtility.UrlEncode(currency) },
                { "locale", HttpUtility.UrlEncode("en-us") },
                { "signed_date_time", HttpUtility.UrlEncode(timestamp) },
                { "signed_field_names", HttpUtility.UrlEncode("access_key,profile_id,transaction_type,reference_number,amount,currency,locale,signed_date_time,signed_field_names,unsigned_field_names,signed_field_values") },
                { "unsigned_field_names", HttpUtility.UrlEncode("") },
                { "signed_field_values", HttpUtility.UrlEncode($"{MerchantId},{ProfileId},sale,{Guid.NewGuid().ToString()},{amount},{currency},en-us,{timestamp},signed_field_names,unsigned_field_names,signed_field_values") },
                { "signature", HttpUtility.UrlEncode(secureToken) },
                { "unsigned_field_values", "" },
                { "response_url", HttpUtility.UrlEncode(ResponseUrl) }
            };

            // Generate the form HTML
            var formHtml = new StringBuilder();
            formHtml.Append("<html><body onload='document.forms[0].submit()'>");
            formHtml.Append($"<form action='{CybersourceApiEndpoint}' method='post'>");
            foreach (var param in formParams)
            {
                formHtml.Append($"<input type='hidden' name='{param.Key}' value='{param.Value}' />");
            }
            formHtml.Append("<noscript><input type='submit' value='Click here to continue' /></noscript>");
            formHtml.Append("</form></body></html>");

            return formHtml.ToString();
        }

        private byte[] HashHMAC(byte[] key, byte[] data)
        {
            using (var hmac = new HMACSHA256(key))
            {
                return hmac.ComputeHash(data);
            }
        }
    }
}

