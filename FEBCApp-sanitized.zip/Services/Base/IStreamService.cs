﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Services.Base
{
    public interface IStreamService
    {

        void Play(string dataSource);
        void Pause();
        void Stop();
    }
}
