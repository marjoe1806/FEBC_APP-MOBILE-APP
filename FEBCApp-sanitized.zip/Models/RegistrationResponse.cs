﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class RegistrationResponse
    {
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        [JsonProperty("first_name", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        [JsonProperty("last_name", NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; }

        [JsonProperty("age", NullValueHandling = NullValueHandling.Ignore)]
        public string Age { get; set; }

        [JsonProperty("gender", NullValueHandling = NullValueHandling.Ignore)]
        public string Gender { get; set; }

        [JsonProperty("country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        [JsonProperty("email_address", NullValueHandling = NullValueHandling.Ignore)]
        public string Username { get; set; }

        [JsonProperty("password", NullValueHandling = NullValueHandling.Ignore)]
        public string Password { get; set; }

        [JsonProperty("user_type", NullValueHandling = NullValueHandling.Ignore)]
        public string Usertype { get; set; }

        //[JsonProperty("salt", NullValueHandling = NullValueHandling.Ignore)]
        //public string Salt { get; set; }

        //[JsonProperty("createdDate", NullValueHandling = NullValueHandling.Ignore)]
        //public DateTime CreateDate { get; set; }

        //[JsonProperty("__v", NullValueHandling = NullValueHandling.Ignore)]
        //public int V { get; set; }

        [JsonProperty("avatar", NullValueHandling = NullValueHandling.Ignore)]
        public string Avatar { get; set; }
    }
}
