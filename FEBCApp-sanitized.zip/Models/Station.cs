﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class Station
    {
        public string Count { get; set; }
        public string StationUrl { get; set; }
        public string ImageUrl { get; set; }
        public string FacebookLink { get; set; }
        public string MessengerLink { get; set; }

    


    }

}
