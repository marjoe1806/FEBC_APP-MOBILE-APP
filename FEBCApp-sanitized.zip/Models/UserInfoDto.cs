﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class UserInfoDto
    {
        //[JsonProperty("employeeNumber", NullValueHandling = NullValueHandling.Ignore)]
        //public string EmployeeNumber { get; set; }

        [JsonProperty("firstname", NullValueHandling = NullValueHandling.Ignore)]
        public string Firstname { get; set; }

        [JsonProperty("lastname", NullValueHandling = NullValueHandling.Ignore)]
        public string Lastname { get; set; }

        [JsonProperty("country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        [JsonProperty("town", NullValueHandling = NullValueHandling.Ignore)]
        public string SelectedCity { get; set; }

        [JsonProperty("province", NullValueHandling = NullValueHandling.Ignore)]
        public string SelectedStated { get; set; }

        [JsonProperty("state", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        [JsonProperty("payment_gateway", NullValueHandling = NullValueHandling.Ignore)]
        public string Gateway { get; set; }


        [JsonProperty("zip_code", NullValueHandling = NullValueHandling.Ignore)]
        public string Zipcode { get; set; }

        [JsonProperty("appartment", NullValueHandling = NullValueHandling.Ignore)]
        public string Appartment { get; set; }

        [JsonProperty("house_no", NullValueHandling = NullValueHandling.Ignore)]
        public string HouseNo { get; set; }

        [JsonProperty("donor_notes", NullValueHandling = NullValueHandling.Ignore)]
        public string DonorNote { get; set; }

        [JsonProperty("radio_station", NullValueHandling = NullValueHandling.Ignore)]
        public string Station { get; set; }

        [JsonProperty("category", NullValueHandling = NullValueHandling.Ignore)]
        public string Category { get; set; }

        [JsonProperty("amount", NullValueHandling = NullValueHandling.Ignore)]
        public string Amount { get; set; }





    }
}
