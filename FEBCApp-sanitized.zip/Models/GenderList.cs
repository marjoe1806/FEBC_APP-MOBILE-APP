﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class GenderList
    {
        public string Gender { get; set; }
        public int Key { get; set; }
    }
}
