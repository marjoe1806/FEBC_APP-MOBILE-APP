﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class FebcUrl
    {
        public string ImageUrl { get; set; }
        public string FacebookUrl { get; set; }
        public string EarthUrl { get; set; }
        public string DonateUrl { get; set; }
    }
}
