﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class UnionBankApiPaymentRequest
    {
        public string MerchantId { get; set; }
        public string ProfileId { get; set; }
        public Int32 Amount { get; set; }
        public string Currency { get; set; }
        public string Description { get; set; }
        public string RedirectUrl { get; set; }
        public string SecretKey { get; set; }
        public string AccessKey { get; set; }
    }
}
