﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class UnionBankApiPaymentResponse
    {
        public string PaymentUrl { get; set; }
    }
}
