﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class AgeList
    {
        public string Age { get; set; }
        public int Key { get; set; }
    }
}
