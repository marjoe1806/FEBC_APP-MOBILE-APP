﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class ImageDto
    {

        [JsonProperty("userid", NullValueHandling = NullValueHandling.Ignore)]
        public string UserId { get; set; }

        [JsonProperty("avatar", NullValueHandling = NullValueHandling.Ignore)]
        public byte[] Avatar { get; set; }

       
    }

}
