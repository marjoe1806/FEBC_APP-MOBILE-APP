﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FEBCApp.Models
{
    public class Category
    {
        public string Name { get; set; }
      
    }
}
