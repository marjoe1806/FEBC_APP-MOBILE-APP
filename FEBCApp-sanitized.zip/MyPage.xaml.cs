﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FEBCApp
{
    public partial class MyPage : ContentPage
    {
        public MyPage()
        {
            InitializeComponent();
        }
    }
}
