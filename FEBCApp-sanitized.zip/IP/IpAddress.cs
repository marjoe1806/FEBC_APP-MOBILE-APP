﻿
using System.Linq;
using System.Net;
using System.Net.Sockets;
using Xamarin.Essentials;
using NetworkAccess = Xamarin.Essentials.NetworkAccess;

namespace FEBCApp.IP
{
    class IpAddress

    { 
        public static string GetIPAddress()
    {
        if (Connectivity.NetworkAccess == NetworkAccess.None)
        {
            return null;
        }

        // Get all IP addresses of the device
        var ipAddresses = Dns.GetHostAddresses(Dns.GetHostName());

        // Find the first non-loopback IPv4 address
        var ipAddress = ipAddresses.FirstOrDefault(ip => !IPAddress.IsLoopback(ip) && ip.AddressFamily == AddressFamily.InterNetwork);

        return ipAddress?.ToString();
    }

}
}
